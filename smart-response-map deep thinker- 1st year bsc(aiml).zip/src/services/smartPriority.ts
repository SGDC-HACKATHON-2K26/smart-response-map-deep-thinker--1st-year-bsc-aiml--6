import { IncidentPriority, IncidentType, SmartPriorityResult } from '../types';

interface KeywordRule {
  pattern: RegExp;
  scoreBonus: number;
  reason: string;
}

const CRITICAL_KEYWORDS: KeywordRule[] = [
  { pattern: /\b(trapped|unconscious|not breathing|cardiac|explosion|mass casualty|drowning|severe burn|massive bleeding)\b/i, scoreBonus: 40, reason: 'Life-threatening condition or trapped victims indicated' },
  { pattern: /\b(flames spreading|building collapse|gas leak|chemical spill|toxic fumes|electrocution)\b/i, scoreBonus: 35, reason: 'Rapid hazard propagation / structural collapse hazard' },
  { pattern: /\b(highway pileup|multiple vehicles|bus crash|train|overturned tanker)\b/i, scoreBonus: 30, reason: 'High-speed multi-casualty transport incident' },
  { pattern: /\b(flash flood|water entering home|swept away|submerged car|river overflow)\b/i, scoreBonus: 30, reason: 'Rapid water level rise or submerged transport' }
];

const HIGH_KEYWORDS: KeywordRule[] = [
  { pattern: /\b(smoke|fire alarm|elderly|children|injured|bleeding|concussion|head injury)\b/i, scoreBonus: 20, reason: 'Vulnerable individuals or active fire/smoke' },
  { pattern: /\b(blocked road|power lines down|live wire|intersection blocked|traffic stopped)\b/i, scoreBonus: 15, reason: 'Severe arterial infrastructure hazard' },
  { pattern: /\b(chest pain|seizure|allergic reaction|stroke|asthma attack)\b/i, scoreBonus: 25, reason: 'Time-critical acute medical symptom' }
];

const BASE_TYPE_SCORES: Record<IncidentType, number> = {
  fire: 55,
  medical: 50,
  flood: 45,
  accident: 40,
  hazard: 35,
  other: 20
};

export function calculateSmartPriority(type: IncidentType, description: string): SmartPriorityResult {
  let score = BASE_TYPE_SCORES[type] || 25;
  const reasons: string[] = [];

  // Base score reasoning
  if (type === 'fire') {
    reasons.push('Fire incidents hold high structural and rapid escalation risk');
  } else if (type === 'medical') {
    reasons.push('Medical alerts receive elevated priority for rapid Golden Hour response');
  } else if (type === 'flood') {
    reasons.push('Flood events can rapidly isolate civilian evacuation routes');
  }

  // Scan critical keywords
  CRITICAL_KEYWORDS.forEach((rule) => {
    if (rule.pattern.test(description)) {
      score += rule.scoreBonus;
      if (!reasons.includes(rule.reason)) {
        reasons.push(rule.reason);
      }
    }
  });

  // Scan high keywords
  HIGH_KEYWORDS.forEach((rule) => {
    if (rule.pattern.test(description)) {
      score += rule.scoreBonus;
      if (!reasons.includes(rule.reason)) {
        reasons.push(rule.reason);
      }
    }
  });

  // Check description length/urgency
  if (description.length > 80 && reasons.length === 0) {
    reasons.push('Standard situational details provided');
  } else if (reasons.length === 0) {
    reasons.push('Preliminary assessment based on incident classification');
  }

  // Bound score between 10 and 100
  const normalizedScore = Math.min(Math.max(score, 10), 100);

  let suggestedPriority: IncidentPriority = 'low';
  if (normalizedScore >= 75) {
    suggestedPriority = 'critical';
  } else if (normalizedScore >= 55) {
    suggestedPriority = 'high';
  } else if (normalizedScore >= 35) {
    suggestedPriority = 'medium';
  } else {
    suggestedPriority = 'low';
  }

  return {
    suggestedPriority,
    reasons,
    severityScore: normalizedScore
  };
}
