import { INITIAL_INCIDENTS } from '../data/initialData';
import { Incident, IncidentStatus, ResponderLogEntry, VerificationStatus } from '../types';

const STORAGE_KEY = 'srm_emergency_incidents_v1';
const FIREBASE_CONFIG_KEY = 'srm_firebase_custom_config_v1';

export interface CustomFirebaseConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket?: string;
  messagingSenderId?: string;
  appId?: string;
  enabled: boolean;
}

// Broadcast channel for multi-tab real-time updates without server setup
let broadcastChannel: BroadcastChannel | null = null;
try {
  if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
    broadcastChannel = new BroadcastChannel('srm_live_updates_channel');
  }
} catch {
  // Graceful fallback if BroadcastChannel is blocked
}

class IncidentStorageService {
  private listeners: Array<(incidents: Incident[]) => void> = [];
  private currentIncidents: Incident[] = [];

  constructor() {
    this.currentIncidents = this.loadFromStorage();
    if (broadcastChannel) {
      broadcastChannel.onmessage = (event) => {
        if (event.data?.type === 'SYNC_INCIDENTS' && Array.isArray(event.data.payload)) {
          this.currentIncidents = event.data.payload;
          this.notifyListeners();
        }
      };
    }
  }

  private loadFromStorage(): Incident[] {
    if (typeof window === 'undefined') return INITIAL_INCIDENTS;
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Could not read from localStorage, using initial dataset', e);
    }
    // Save initial demo dataset
    this.saveToStorage(INITIAL_INCIDENTS);
    return INITIAL_INCIDENTS;
  }

  private saveToStorage(incidents: Incident[]): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(incidents));
    } catch (e) {
      console.warn('Failed to save incidents to localStorage', e);
    }
  }

  private notifyListeners(): void {
    this.listeners.forEach((listener) => {
      try {
        listener([...this.currentIncidents]);
      } catch (err) {
        console.error('Error invoking incident listener', err);
      }
    });
  }

  private broadcastUpdate(): void {
    this.saveToStorage(this.currentIncidents);
    this.notifyListeners();
    if (broadcastChannel) {
      try {
        broadcastChannel.postMessage({
          type: 'SYNC_INCIDENTS',
          payload: this.currentIncidents
        });
      } catch (e) {
        console.warn('Failed to broadcast across tabs', e);
      }
    }
  }

  public getIncidents(): Incident[] {
    return [...this.currentIncidents];
  }

  public subscribe(callback: (incidents: Incident[]) => void): () => void {
    this.listeners.push(callback);
    callback([...this.currentIncidents]);
    return () => {
      this.listeners = this.listeners.filter((cb) => cb !== callback);
    };
  }

  public addIncident(newIncident: Incident): Incident {
    // New live report
    this.currentIncidents = [newIncident, ...this.currentIncidents];
    this.broadcastUpdate();
    return newIncident;
  }

  public updateIncidentStatus(
    id: string,
    status: IncidentStatus,
    assignedUnit?: string,
    logNote?: ResponderLogEntry
  ): boolean {
    let found = false;
    this.currentIncidents = this.currentIncidents.map((inc) => {
      if (inc.id === id) {
        found = true;
        const notes = inc.responderNotes ? [...inc.responderNotes] : [];
        if (logNote) {
          notes.unshift(logNote);
        }
        return {
          ...inc,
          status,
          assignedUnit: assignedUnit !== undefined ? assignedUnit : inc.assignedUnit,
          updatedAt: Date.now(),
          responderNotes: notes
        };
      }
      return inc;
    });

    if (found) {
      this.broadcastUpdate();
    }
    return found;
  }

  public updateVerification(
    id: string,
    verificationStatus: VerificationStatus,
    responderName: string,
    badgeNumber: string,
    noteText: string
  ): boolean {
    const logEntry: ResponderLogEntry = {
      id: 'log-' + Date.now(),
      timestamp: Date.now(),
      responderName,
      badgeNumber,
      action: verificationStatus === 'verified' ? 'Report Verified' : 'Marked False Alarm',
      note: noteText
    };

    let found = false;
    this.currentIncidents = this.currentIncidents.map((inc) => {
      if (inc.id === id) {
        found = true;
        const notes = inc.responderNotes ? [...inc.responderNotes] : [];
        notes.unshift(logEntry);
        return {
          ...inc,
          verificationStatus,
          status: verificationStatus === 'false_alarm' ? 'dismissed' : inc.status,
          updatedAt: Date.now(),
          responderNotes: notes
        };
      }
      return inc;
    });

    if (found) {
      this.broadcastUpdate();
    }
    return found;
  }

  public linkDuplicate(duplicateIncidentId: string, parentIncidentId: string): void {
    this.currentIncidents = this.currentIncidents.map((inc) => {
      if (inc.id === duplicateIncidentId) {
        return {
          ...inc,
          duplicateOfId: parentIncidentId,
          status: 'resolved',
          updatedAt: Date.now()
        };
      }
      if (inc.id === parentIncidentId) {
        return {
          ...inc,
          duplicateCount: (inc.duplicateCount || 0) + 1,
          updatedAt: Date.now()
        };
      }
      return inc;
    });
    this.broadcastUpdate();
  }

  public resetToDemo(): void {
    this.currentIncidents = [...INITIAL_INCIDENTS];
    this.broadcastUpdate();
  }

  public getFirebaseConfig(): CustomFirebaseConfig | null {
    if (typeof window === 'undefined') return null;
    try {
      const saved = localStorage.getItem(FIREBASE_CONFIG_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return null;
  }

  public saveFirebaseConfig(config: CustomFirebaseConfig): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(FIREBASE_CONFIG_KEY, JSON.stringify(config));
    } catch (e) {
      console.warn('Could not save firebase config', e);
    }
  }
}

export const incidentService = new IncidentStorageService();
