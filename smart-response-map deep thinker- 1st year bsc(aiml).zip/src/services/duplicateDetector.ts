import { DuplicateDetectionResult, Incident, IncidentType, LocationCoords } from '../types';

/**
 * Calculates distance between two GPS coordinates in meters using Haversine formula
 */
export function calculateDistanceMeters(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3; // Earth radius in meters
  const phi1 = (lat1 * Math.PI) / 180;
  const phi2 = (lat2 * Math.PI) / 180;
  const deltaPhi = ((lat2 - lat1) * Math.PI) / 180;
  const deltaLambda = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return Math.round(R * c);
}

/**
 * Checks if a new incident is a potential duplicate of an existing unresolved incident
 */
export function detectPotentialDuplicate(
  newType: IncidentType,
  newLocation: LocationCoords,
  existingIncidents: Incident[],
  timeWindowMinutes: number = 180, // 3 hours window
  maxDistanceMeters: number = 600   // 600 meters proximity
): DuplicateDetectionResult {
  const now = Date.now();
  let bestMatch: Incident | undefined;
  let highestConfidence = 0;
  let matchDistance = 0;
  let matchTimeDiff = 0;

  for (const incident of existingIncidents) {
    // Only compare against active/pending incidents (ignore already resolved ones)
    if (incident.status === 'resolved' || incident.status === 'dismissed') {
      continue;
    }

    const distance = calculateDistanceMeters(
      newLocation.lat,
      newLocation.lng,
      incident.location.lat,
      incident.location.lng
    );

    const timeDiffMinutes = Math.abs(now - incident.reportedAt) / (1000 * 60);

    if (distance <= maxDistanceMeters && timeDiffMinutes <= timeWindowMinutes) {
      // Calculate confidence
      let confidence = 0;
      
      // Proximity factor (closer = higher)
      if (distance < 100) confidence += 50;
      else if (distance < 250) confidence += 40;
      else if (distance < 450) confidence += 25;
      else confidence += 15;

      // Type matching
      if (incident.type === newType) {
        confidence += 35;
      } else if (
        (incident.type === 'accident' && newType === 'hazard') ||
        (incident.type === 'fire' && newType === 'hazard')
      ) {
        confidence += 20;
      }

      // Time proximity
      if (timeDiffMinutes < 30) confidence += 15;
      else if (timeDiffMinutes < 60) confidence += 10;
      else confidence += 5;

      if (confidence > highestConfidence) {
        highestConfidence = Math.min(confidence, 98);
        bestMatch = incident;
        matchDistance = distance;
        matchTimeDiff = Math.round(timeDiffMinutes);
      }
    }
  }

  const isDuplicate = highestConfidence >= 55 && bestMatch !== undefined;

  return {
    isPotentialDuplicate: isDuplicate,
    matchedIncident: bestMatch,
    confidenceScore: highestConfidence,
    distanceMeters: matchDistance,
    timeDiffMinutes: matchTimeDiff
  };
}
