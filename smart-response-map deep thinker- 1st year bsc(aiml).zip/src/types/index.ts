export type IncidentType = 'accident' | 'fire' | 'flood' | 'medical' | 'hazard' | 'other';

export type IncidentPriority = 'critical' | 'high' | 'medium' | 'low';

export type IncidentStatus = 'pending' | 'ongoing' | 'resolved' | 'dismissed';

export type VerificationStatus = 'unverified' | 'verified' | 'false_alarm';

export interface LocationCoords {
  lat: number;
  lng: number;
  address: string;
}

export interface ResponderLogEntry {
  id: string;
  timestamp: number;
  responderName: string;
  badgeNumber: string;
  action: string;
  note: string;
}

export interface Incident {
  id: string;
  reportCode: string; // e.g., "SRM-9021"
  type: IncidentType;
  title: string;
  description: string;
  location: LocationCoords;
  priority: IncidentPriority;
  priorityReasons: string[];
  status: IncidentStatus;
  verificationStatus: VerificationStatus;
  reportedAt: number; // Unix timestamp
  updatedAt: number;
  reporterName?: string;
  reporterContact?: string;
  imageUrl?: string;
  assignedUnit?: string;
  responderNotes?: ResponderLogEntry[];
  isDemo: boolean;
  duplicateOfId?: string; // Linked parent incident if duplicate
  duplicateScore?: number; // Match confidence percentage (0-100)
  duplicateCount?: number; // How many duplicates have reported this
}

export interface EmergencyFacility {
  id: string;
  name: string;
  type: 'hospital' | 'police' | 'fire_station';
  location: LocationCoords;
  phone: string;
  availableUnits: number;
  status: 'available' | 'busy' | 'dispatched';
  distanceKm?: number;
}

export interface ResponderUser {
  id: string;
  name: string;
  badgeNumber: string;
  role: 'Chief Dispatcher' | 'Fire Battalion Chief' | 'Lead Paramedic' | 'Police Commander' | 'Field Responder';
  agency: 'City Emergency Operations' | 'Metropolitan Fire Dept' | 'Emergency Medical Services' | 'Metro Police';
  accessLevel: 'admin' | 'field';
}

export interface SmartPriorityResult {
  suggestedPriority: IncidentPriority;
  reasons: string[];
  severityScore: number; // 1-100
}

export interface DuplicateDetectionResult {
  isPotentialDuplicate: boolean;
  matchedIncident?: Incident;
  confidenceScore: number; // 0 - 100
  distanceMeters: number;
  timeDiffMinutes: number;
}
