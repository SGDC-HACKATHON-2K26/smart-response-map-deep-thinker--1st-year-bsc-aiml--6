import React from 'react';
import { EmergencyFacility, LocationCoords } from '../../types';
import { calculateDistanceMeters } from '../../services/duplicateDetector';
import { Hospital, Shield, Flame, Phone, CheckCircle, Navigation, MapPin } from 'lucide-react';

interface NearbyServicesListProps {
  facilities: EmergencyFacility[];
  referenceLocation?: LocationCoords | null;
  onFacilityClick?: (facility: EmergencyFacility) => void;
  showHospitals: boolean;
  setShowHospitals: (show: boolean) => void;
  showPolice: boolean;
  setShowPolice: (show: boolean) => void;
  showFireStations: boolean;
  setShowFireStations: (show: boolean) => void;
}

export const NearbyServicesList: React.FC<NearbyServicesListProps> = ({
  facilities,
  referenceLocation,
  onFacilityClick,
  showHospitals,
  setShowHospitals,
  showPolice,
  setShowPolice,
  showFireStations,
  setShowFireStations
}) => {
  // Calculate distance if reference location is provided
  const facilitiesWithDistance = facilities.map((facility) => {
    let distanceKm: number | undefined;
    if (referenceLocation) {
      const meters = calculateDistanceMeters(
        referenceLocation.lat,
        referenceLocation.lng,
        facility.location.lat,
        facility.location.lng
      );
      distanceKm = Number((meters / 1000).toFixed(1));
    }
    return { ...facility, distanceKm };
  });

  // Sort by closest if distance is available
  if (referenceLocation) {
    facilitiesWithDistance.sort((a, b) => (a.distanceKm ?? 999) - (b.distanceKm ?? 999));
  }

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-4">
      {/* Title & Filter toggles */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
        <div>
          <h3 className="text-sm font-bold text-slate-900">Nearby Emergency Services</h3>
          <p className="text-xs text-slate-500">
            {referenceLocation ? `Measured from: ${referenceLocation.address}` : 'City Emergency Assets Standby'}
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            type="button"
            onClick={() => setShowHospitals(!showHospitals)}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors ${
              showHospitals ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-400 line-through'
            }`}
          >
            <span>🏥 Hospitals</span>
          </button>
          <button
            type="button"
            onClick={() => setShowPolice(!showPolice)}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors ${
              showPolice ? 'bg-indigo-100 text-indigo-800' : 'bg-slate-100 text-slate-400 line-through'
            }`}
          >
            <span>🚓 Police</span>
          </button>
          <button
            type="button"
            onClick={() => setShowFireStations(!showFireStations)}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors ${
              showFireStations ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-400 line-through'
            }`}
          >
            <span>🚒 Fire</span>
          </button>
        </div>
      </div>

      {/* Facility Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {facilitiesWithDistance.map((facility) => {
          let iconColor = 'text-blue-600';
          let borderAccent = 'hover:border-blue-400';
          let typeLabel = 'Hospital / Trauma';

          if (facility.type === 'police') {
            iconColor = 'text-indigo-600';
            borderAccent = 'hover:border-indigo-400';
            typeLabel = 'Police Station';
          } else if (facility.type === 'fire_station') {
            iconColor = 'text-rose-600';
            borderAccent = 'hover:border-rose-400';
            typeLabel = 'Fire Station';
          }

          return (
            <div
              key={facility.id}
              onClick={() => onFacilityClick && onFacilityClick(facility)}
              className={`p-3 rounded-xl border border-slate-200 hover:shadow-md transition-all cursor-pointer bg-slate-50/50 ${borderAccent}`}
            >
              <div className="flex items-start justify-between gap-2 mb-1.5">
                <span className={`text-[11px] font-bold uppercase tracking-wider ${iconColor}`}>
                  {typeLabel}
                </span>
                {facility.distanceKm !== undefined && (
                  <span className="text-[11px] font-semibold text-slate-600 font-mono-numbers bg-white px-2 py-0.5 rounded border border-slate-200">
                    {facility.distanceKm} km away
                  </span>
                )}
              </div>

              <h4 className="text-xs font-bold text-slate-900 mb-1 leading-snug">
                {facility.name}
              </h4>
              <p className="text-[11px] text-slate-500 mb-2 truncate">
                📍 {facility.location.address}
              </p>

              <div className="flex items-center justify-between pt-2 border-t border-slate-200/60 text-xs">
                <a
                  href={`tel:${facility.phone}`}
                  onClick={(e) => e.stopPropagation()}
                  className="text-blue-600 hover:text-blue-800 font-semibold flex items-center gap-1"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>{facility.phone}</span>
                </a>
                <span className="text-emerald-600 font-semibold text-[11px] flex items-center gap-1 font-mono-numbers">
                  <CheckCircle className="w-3 h-3" />
                  {facility.availableUnits} units ready
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
