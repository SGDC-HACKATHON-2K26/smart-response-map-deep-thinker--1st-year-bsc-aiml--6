import React from 'react';
import { Incident } from '../../types';
import { AlertCircle, Clock, Activity, CheckCircle2, Flame, ShieldAlert } from 'lucide-react';

interface OverviewStatsProps {
  incidents: Incident[];
  activeFilter: string;
  onFilterChange: (status: string) => void;
}

export const OverviewStats: React.FC<OverviewStatsProps> = ({
  incidents,
  activeFilter,
  onFilterChange
}) => {
  const total = incidents.length;
  const pending = incidents.filter((i) => i.status === 'pending').length;
  const ongoing = incidents.filter((i) => i.status === 'ongoing').length;
  const resolved = incidents.filter((i) => i.status === 'resolved').length;
  const critical = incidents.filter((i) => i.priority === 'critical' && i.status !== 'resolved').length;

  return (
    <div className="space-y-4">
      {/* 4 Primary KPI metric cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Total */}
        <button
          type="button"
          onClick={() => onFilterChange('all')}
          className={`p-4 rounded-xl border text-left transition-all ${
            activeFilter === 'all'
              ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
              : 'bg-white text-slate-800 border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className={`text-xs font-semibold uppercase tracking-wider ${activeFilter === 'all' ? 'text-slate-300' : 'text-slate-500'}`}>
              Total Incidents
            </span>
            <AlertCircle className={`w-4 h-4 ${activeFilter === 'all' ? 'text-blue-400' : 'text-slate-400'}`} />
          </div>
          <div className="text-2xl font-bold font-mono-numbers">
            {total}
          </div>
          <div className={`text-[11px] mt-1 ${activeFilter === 'all' ? 'text-slate-300' : 'text-slate-500'}`}>
            <span>All recorded alerts</span>
          </div>
        </button>

        {/* Pending */}
        <button
          type="button"
          onClick={() => onFilterChange('pending')}
          className={`p-4 rounded-xl border text-left transition-all ${
            activeFilter === 'pending'
              ? 'bg-amber-50 border-amber-400 ring-1 ring-amber-400 text-amber-950 shadow-sm'
              : 'bg-white text-slate-800 border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-amber-700">
              Pending Review
            </span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold font-mono-numbers text-amber-600">
            {pending}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            <span>Awaiting field dispatch</span>
          </div>
        </button>

        {/* Ongoing */}
        <button
          type="button"
          onClick={() => onFilterChange('ongoing')}
          className={`p-4 rounded-xl border text-left transition-all ${
            activeFilter === 'ongoing'
              ? 'bg-orange-50 border-orange-400 ring-1 ring-orange-400 text-orange-950 shadow-sm'
              : 'bg-white text-slate-800 border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-orange-700">
              Ongoing / Active
            </span>
            <Activity className="w-4 h-4 text-orange-500" />
          </div>
          <div className="text-2xl font-bold font-mono-numbers text-orange-600">
            {ongoing}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            <span>Units on scene / responding</span>
          </div>
        </button>

        {/* Resolved */}
        <button
          type="button"
          onClick={() => onFilterChange('resolved')}
          className={`p-4 rounded-xl border text-left transition-all ${
            activeFilter === 'resolved'
              ? 'bg-emerald-50 border-emerald-400 ring-1 ring-emerald-400 text-emerald-950 shadow-sm'
              : 'bg-white text-slate-800 border-slate-200 hover:border-slate-300'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider text-emerald-700">
              Resolved Cases
            </span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold font-mono-numbers text-emerald-600">
            {resolved}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            <span>Secured & closed</span>
          </div>
        </button>
      </div>

      {/* Critical alert banner if critical incidents exist */}
      {critical > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-xl p-3 flex items-center justify-between text-xs text-red-900">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-red-600 shrink-0" />
            <span className="font-semibold">
              High Severity Notice: {critical} critical incidents currently require urgent response.
            </span>
          </div>
          <span className="text-[11px] text-red-600 font-semibold hidden sm:inline">
            Priority 1 Protocol Engaged
          </span>
        </div>
      )}
    </div>
  );
};
