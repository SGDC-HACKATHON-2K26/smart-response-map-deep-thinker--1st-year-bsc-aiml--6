import React, { useState } from 'react';
import { Incident, IncidentStatus, ResponderUser, VerificationStatus } from '../../types';
import { DEMO_RESPONDERS } from '../../data/initialData';
import { 
  ShieldCheck, ShieldAlert, Lock, CheckCircle2, AlertOctagon, 
  Send, UserCheck, Clock, Truck, FileText, ChevronRight, X 
} from 'lucide-react';

interface ResponderConsoleModalProps {
  isOpen: boolean;
  onClose: () => void;
  incident: Incident | null;
  onUpdateStatus: (incidentId: string, status: IncidentStatus, assignedUnit?: string, note?: string) => void;
  onVerify: (incidentId: string, isVerified: boolean, note: string) => void;
  currentResponder: ResponderUser | null;
  onLoginResponder: (responder: ResponderUser) => void;
  onLogoutResponder: () => void;
}

export const ResponderConsoleModal: React.FC<ResponderConsoleModalProps> = ({
  isOpen,
  onClose,
  incident,
  onUpdateStatus,
  onVerify,
  currentResponder,
  onLoginResponder,
  onLogoutResponder
}) => {
  const [selectedResponderIdx, setSelectedResponderIdx] = useState(0);
  const [passcode, setPasscode] = useState('1234');
  const [authError, setAuthError] = useState<string | null>(null);

  // Status update state
  const [targetStatus, setTargetStatus] = useState<IncidentStatus>(incident?.status || 'ongoing');
  const [unitInput, setUnitInput] = useState(incident?.assignedUnit || '');
  const [responderNote, setResponderNote] = useState('');
  const [verifyNote, setVerifyNote] = useState('');

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const candidate = DEMO_RESPONDERS[selectedResponderIdx];
    if (passcode === candidate.passcode) {
      onLoginResponder({
        id: candidate.id,
        name: candidate.name,
        badgeNumber: candidate.badgeNumber,
        role: candidate.role as any,
        agency: candidate.agency as any,
        accessLevel: candidate.accessLevel as any
      });
      setAuthError(null);
    } else {
      setAuthError('Invalid badge passcode. (Demo default passcode is 1234)');
    }
  };

  const handleStatusSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!incident) return;
    onUpdateStatus(incident.id, targetStatus, unitInput.trim() || undefined, responderNote.trim() || undefined);
    setResponderNote('');
    onClose();
  };

  const handleVerificationAction = (isVerified: boolean) => {
    if (!incident) return;
    const defaultNote = isVerified 
      ? 'Field assessment confirms active incident parameters.'
      : 'Caller reported situation cleared or false alarm report.';
    onVerify(incident.id, isVerified, verifyNote.trim() || defaultNote);
    setVerifyNote('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[1100] bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white leading-tight">Authorized Responder Command</h3>
              <p className="text-xs text-slate-400">Incident verification, dispatch, and lifecycle control</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Auth Check: If not logged in as responder */}
        {!currentResponder ? (
          <div className="p-6">
            <div className="bg-blue-50/70 border border-blue-200 rounded-xl p-4 mb-5 flex items-start gap-3">
              <Lock className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              <div className="text-xs text-slate-700">
                <p className="font-bold text-blue-950 mb-1">Restricted Tactical Access</p>
                <p>To verify incidents, change severity, and assign units, you must authenticate as an authorized emergency responder or dispatcher.</p>
              </div>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Select Responder Identity
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {DEMO_RESPONDERS.map((responder, idx) => (
                    <div
                      key={responder.id}
                      onClick={() => setSelectedResponderIdx(idx)}
                      className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                        selectedResponderIdx === idx
                          ? 'border-blue-600 bg-blue-50/60 ring-1 ring-blue-600'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div className="font-bold text-slate-900">{responder.name}</div>
                      <div className="text-slate-500">{responder.role}</div>
                      <div className="text-[11px] text-blue-600 font-mono-numbers mt-1">
                        {responder.badgeNumber} · {responder.agency}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Security Passcode
                </label>
                <div className="flex gap-2">
                  <input
                    type="password"
                    value={passcode}
                    onChange={(e) => setPasscode(e.target.value)}
                    placeholder="Enter responder passcode (Default: 1234)"
                    className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 text-slate-900"
                  />
                  <button
                    type="submit"
                    className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-5 py-2.5 rounded-xl text-xs transition-colors flex items-center gap-1.5 shrink-0"
                  >
                    <span>Authenticate</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Hackathon / Demo passcode is prefilled: <strong className="text-slate-600">1234</strong>
                </span>
                {authError && (
                  <p className="text-xs text-red-600 mt-1.5 font-medium">{authError}</p>
                )}
              </div>
            </form>
          </div>
        ) : (
          /* Authenticated Responder View */
          <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
            {/* Responder Active Session Card */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-sm">
                  {currentResponder.name.charAt(0)}
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <span>{currentResponder.name}</span>
                    <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md">
                      ACTIVE RESPONDER
                    </span>
                  </div>
                  <div className="text-xs text-slate-500 font-mono-numbers">
                    {currentResponder.role} · Badge #{currentResponder.badgeNumber} · {currentResponder.agency}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={onLogoutResponder}
                className="text-xs text-slate-500 hover:text-red-600 font-semibold px-2 py-1 rounded transition-colors"
              >
                Sign Out
              </button>
            </div>

            {incident ? (
              <div className="space-y-6">
                {/* Selected Incident Summary */}
                <div className="border border-slate-200 rounded-xl p-4 bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-mono font-bold text-slate-500">{incident.reportCode}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700 uppercase">
                        Current Status: {incident.status}
                      </span>
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded uppercase ${
                        incident.verificationStatus === 'verified'
                          ? 'bg-emerald-100 text-emerald-700'
                          : incident.verificationStatus === 'false_alarm'
                          ? 'bg-red-100 text-red-700'
                          : 'bg-amber-100 text-amber-700'
                      }`}>
                        {incident.verificationStatus}
                      </span>
                    </div>
                  </div>
                  <h4 className="text-base font-bold text-slate-900 mb-1">{incident.title}</h4>
                  <p className="text-xs text-slate-600 mb-2">{incident.description}</p>
                  <div className="text-xs text-slate-500">📍 {incident.location.address}</div>
                </div>

                {/* Verification Actions */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                    1. Report Verification
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-2">
                    <button
                      type="button"
                      onClick={() => handleVerificationAction(true)}
                      className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 p-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Verify Incident (Legitimate)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleVerificationAction(false)}
                      className="bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-300 p-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors"
                    >
                      <AlertOctagon className="w-4 h-4 text-rose-600" />
                      <span>Mark False Alarm / Dismiss</span>
                    </button>
                  </div>
                </div>

                {/* Status & Unit Dispatch */}
                <form onSubmit={handleStatusSubmit} className="space-y-4 pt-2 border-t border-slate-100">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                      2. Update Incident Status & Dispatch
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['pending', 'ongoing', 'resolved'] as IncidentStatus[]).map((st) => (
                        <button
                          key={st}
                          type="button"
                          onClick={() => setTargetStatus(st)}
                          className={`py-2 px-3 rounded-xl text-xs font-bold capitalize transition-all border ${
                            targetStatus === st
                              ? st === 'resolved'
                                ? 'bg-emerald-600 text-white border-emerald-600 shadow'
                                : st === 'ongoing'
                                ? 'bg-orange-500 text-white border-orange-500 shadow'
                                : 'bg-amber-500 text-white border-amber-500 shadow'
                              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          {st === 'ongoing' ? 'Ongoing (Dispatched)' : st}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Assigned Responding Unit(s)
                    </label>
                    <div className="relative">
                      <Truck className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                      <input
                        type="text"
                        placeholder="e.g. Engine 4 & Medic 9, Patrol Unit 204"
                        value={unitInput}
                        onChange={(e) => setUnitInput(e.target.value)}
                        className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-300 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Responder Operational Log Note
                    </label>
                    <textarea
                      rows={2}
                      placeholder="Add field notes, perimeter status, or patient transfer update..."
                      value={responderNote}
                      onChange={(e) => setResponderNote(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-2.5 px-4 rounded-xl text-xs transition-colors flex items-center justify-center gap-2 shadow"
                  >
                    <Send className="w-4 h-4" />
                    <span>Apply Status & Broadcast Operational Update</span>
                  </button>
                </form>

                {/* Existing Responder Logs */}
                {incident.responderNotes && incident.responderNotes.length > 0 && (
                  <div className="pt-2 border-t border-slate-100">
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                      Official Tactical Timeline
                    </label>
                    <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                      {incident.responderNotes.map((log) => (
                        <div key={log.id} className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-xs">
                          <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                            <span className="font-bold text-slate-800">{log.responderName} ({log.badgeNumber})</span>
                            <span>{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          </div>
                          <div className="font-semibold text-blue-700 text-[11px] mb-0.5">{log.action}</div>
                          <p className="text-slate-600 text-xs">{log.note}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-8 text-center text-slate-500 text-sm">
                Please select an incident from the map or incident list to manage its verification and status.
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
