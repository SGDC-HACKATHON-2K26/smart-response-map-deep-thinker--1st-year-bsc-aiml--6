import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { EmergencyFacility, Incident, IncidentPriority, IncidentType } from '../../types';
import { MAP_CENTER } from '../../data/initialData';
import { Flame, AlertTriangle, Activity, Car, Waves, Hospital, Shield, Compass, Navigation } from 'lucide-react';

interface IncidentMapProps {
  incidents: Incident[];
  facilities: EmergencyFacility[];
  selectedIncident: Incident | null;
  onSelectIncident: (incident: Incident) => void;
  isPickingLocation?: boolean;
  pickedCoords?: { lat: number; lng: number } | null;
  onPickCoords?: (coords: { lat: number; lng: number }) => void;
  filterStatus?: string;
  filterType?: string;
  showHospitals?: boolean;
  showPolice?: boolean;
  showFireStations?: boolean;
}

export const IncidentMap: React.FC<IncidentMapProps> = ({
  incidents,
  facilities,
  selectedIncident,
  onSelectIncident,
  isPickingLocation = false,
  pickedCoords = null,
  onPickCoords,
  filterStatus = 'all',
  filterType = 'all',
  showHospitals = true,
  showPolice = true,
  showFireStations = true
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const incidentMarkersRef = useRef<{ [id: string]: L.Marker }>({});
  const facilityMarkersRef = useRef<{ [id: string]: L.Marker }>({});
  const pickMarkerRef = useRef<L.Marker | null>(null);
  const [mapReady, setMapReady] = useState(false);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center: MAP_CENTER,
      zoom: 13,
      zoomControl: false,
      attributionControl: false
    });

    // Clean OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    // Zoom control at bottom right for clean layout
    L.control.zoom({ position: 'bottomright' }).addTo(map);

    // Attribution
    L.control.attribution({ position: 'bottomleft', prefix: false }).addAttribution('© OpenStreetMap').addTo(map);

    // Click handler for picking location
    map.on('click', (e: L.LeafletMouseEvent) => {
      if (onPickCoords) {
        onPickCoords({ lat: Number(e.latlng.lat.toFixed(5)), lng: Number(e.latlng.lng.toFixed(5)) });
      }
    });

    mapInstanceRef.current = map;
    setMapReady(true);

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Pan to selected incident
  useEffect(() => {
    if (!mapInstanceRef.current || !selectedIncident) return;
    mapInstanceRef.current.flyTo(
      [selectedIncident.location.lat, selectedIncident.location.lng],
      15,
      { duration: 1.2 }
    );
  }, [selectedIncident]);

  // Handle Pick Marker
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (pickedCoords) {
      if (pickMarkerRef.current) {
        pickMarkerRef.current.setLatLng([pickedCoords.lat, pickedCoords.lng]);
      } else {
        const pickIcon = L.divIcon({
          className: 'pick-location-marker',
          html: `
            <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 44px; height: 44px;">
              <span style="position: absolute; width: 44px; height: 44px; background: rgba(59, 130, 246, 0.35); border-radius: 50%; animation: pulse-ring 1.5s infinite;"></span>
              <div style="width: 24px; height: 24px; background: #2563EB; border: 3px solid #ffffff; border-radius: 50%; box-shadow: 0 4px 10px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center;">
                <div style="width: 6px; height: 6px; background: #ffffff; border-radius: 50%;"></div>
              </div>
            </div>
          `,
          iconSize: [44, 44],
          iconAnchor: [22, 22]
        });

        pickMarkerRef.current = L.marker([pickedCoords.lat, pickedCoords.lng], {
          icon: pickIcon,
          zIndexOffset: 1000
        }).addTo(map);
      }
    } else if (pickMarkerRef.current) {
      pickMarkerRef.current.remove();
      pickMarkerRef.current = null;
    }
  }, [pickedCoords]);

  // Render Incident Markers
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !mapReady) return;

    // Clear old markers
    Object.values(incidentMarkersRef.current).forEach((m) => m.remove());
    incidentMarkersRef.current = {};

    // Filter incidents
    const filtered = incidents.filter((inc) => {
      if (filterStatus !== 'all' && inc.status !== filterStatus) return false;
      if (filterType !== 'all' && inc.type !== filterType) return false;
      return true;
    });

    filtered.forEach((incident) => {
      // Determine marker color by status & priority
      let colorBg = '#F59E0B'; // orange
      let ringColor = 'rgba(245, 158, 11, 0.4)';
      let pulseClass = '';

      if (incident.status === 'resolved') {
        colorBg = '#10B981'; // Green for resolved
        ringColor = 'rgba(16, 185, 129, 0.3)';
      } else if (incident.priority === 'critical') {
        colorBg = '#EF4444'; // Red for critical
        ringColor = 'rgba(239, 68, 68, 0.5)';
        pulseClass = 'marker-pulse-critical';
      } else if (incident.priority === 'high' || incident.status === 'ongoing') {
        colorBg = '#F97316'; // Deep orange
        ringColor = 'rgba(249, 115, 22, 0.4)';
        pulseClass = 'marker-pulse-ongoing';
      } else if (incident.status === 'pending') {
        colorBg = '#EAB308'; // Amber/Yellow
        ringColor = 'rgba(234, 179, 8, 0.4)';
      }

      // Icon symbol representation
      let iconSvg = '';
      if (incident.type === 'fire') {
        iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/></svg>`;
      } else if (incident.type === 'accident') {
        iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2"/><circle cx="7" cy="17" r="2"/><path d="M9 17h6"/><circle cx="17" cy="17" r="2"/></svg>`;
      } else if (incident.type === 'medical') {
        iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>`;
      } else if (incident.type === 'flood') {
        iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/><path d="M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/><path d="M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1"/></svg>`;
      } else {
        iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;
      }

      const customIcon = L.divIcon({
        className: 'srm-incident-marker',
        html: `
          <div class="${pulseClass}" style="position: relative; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: transform 0.2s;">
            <div style="width: 36px; height: 36px; background-color: ${colorBg}; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 12px ${ringColor}; border: 2.5px solid #ffffff;">
              ${iconSvg}
            </div>
            ${incident.isDemo ? '' : '<span style="position: absolute; -top: 4px; right: -4px; width: 10px; height: 10px; background: #3B82F6; border: 2px solid #ffffff; border-radius: 50%;"></span>'}
          </div>
        `,
        iconSize: [36, 36],
        iconAnchor: [18, 18]
      });

      const marker = L.marker([incident.location.lat, incident.location.lng], {
        icon: customIcon
      });

      // Bind interactive popup
      const statusLabel = incident.status.toUpperCase();
      const priorityLabel = incident.priority.toUpperCase();
      const popupHtml = `
        <div style="font-family: inherit; min-width: 240px; padding: 12px;">
          <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 6px;">
            <span style="font-size: 11px; font-weight: 700; color: #64748B;">${incident.reportCode}</span>
            <span style="font-size: 11px; font-weight: 600; padding: 2px 6px; border-radius: 4px; background: ${colorBg}20; color: ${colorBg};">
              ${priorityLabel} · ${statusLabel}
            </span>
          </div>
          <h4 style="font-size: 14px; font-weight: 700; color: #0F172A; margin: 0 0 6px 0; line-height: 1.3;">
            ${incident.title}
          </h4>
          <p style="font-size: 12px; color: #475569; margin: 0 0 8px 0; max-height: 52px; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;">
            ${incident.description}
          </p>
          <div style="font-size: 11px; color: #64748B; margin-bottom: 10px;">
            📍 ${incident.location.address}
          </div>
          <button id="btn-view-inc-${incident.id}" style="width: 100%; background: #0F172A; color: #FFFFFF; border: none; padding: 8px; border-radius: 6px; font-size: 12px; font-weight: 600; cursor: pointer;">
            Open Incident Command Details
          </button>
        </div>
      `;

      marker.bindPopup(popupHtml, {
        className: 'custom-leaflet-popup',
        offset: [0, -10]
      });

      marker.on('popupopen', () => {
        const btn = document.getElementById(`btn-view-inc-${incident.id}`);
        if (btn) {
          btn.onclick = () => {
            onSelectIncident(incident);
          };
        }
      });

      marker.on('click', () => {
        onSelectIncident(incident);
      });

      marker.addTo(map);
      incidentMarkersRef.current[incident.id] = marker;
    });
  }, [incidents, filterStatus, filterType, mapReady]);

  // Render Facilities (Hospitals, Police, Fire Stations)
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map || !mapReady) return;

    // Clear old facility markers
    Object.values(facilityMarkersRef.current).forEach((m) => m.remove());
    facilityMarkersRef.current = {};

    facilities.forEach((facility) => {
      if (facility.type === 'hospital' && !showHospitals) return;
      if (facility.type === 'police' && !showPolice) return;
      if (facility.type === 'fire_station' && !showFireStations) return;

      let facColor = '#3B82F6';
      let iconEmoji = '🏥';
      let labelType = 'Hospital & Trauma';

      if (facility.type === 'police') {
        facColor = '#1E3A8A';
        iconEmoji = '🚓';
        labelType = 'Police Precinct';
      } else if (facility.type === 'fire_station') {
        facColor = '#DC2626';
        iconEmoji = '🚒';
        labelType = 'Fire & Rescue';
      }

      const facIcon = L.divIcon({
        className: 'srm-facility-marker',
        html: `
          <div style="width: 30px; height: 30px; background: #ffffff; border-radius: 8px; border: 2px solid ${facColor}; box-shadow: 0 4px 6px rgba(0,0,0,0.15); display: flex; align-items: center; justify-content: center; font-size: 15px; cursor: pointer;">
            ${iconEmoji}
          </div>
        `,
        iconSize: [30, 30],
        iconAnchor: [15, 15]
      });

      const marker = L.marker([facility.location.lat, facility.location.lng], {
        icon: facIcon
      });

      marker.bindPopup(`
        <div style="padding: 10px; font-family: inherit; min-width: 220px;">
          <div style="font-size: 11px; font-weight: 700; color: ${facColor}; text-transform: uppercase;">${labelType}</div>
          <h4 style="font-size: 13px; font-weight: 700; margin: 4px 0 6px 0; color: #0F172A;">${facility.name}</h4>
          <div style="font-size: 11px; color: #475569; margin-bottom: 4px;">📍 ${facility.location.address}</div>
          <div style="font-size: 11px; color: #0F172A; font-weight: 600; margin-bottom: 6px;">📞 <a href="tel:${facility.phone}" style="color: #2563EB;">${facility.phone}</a></div>
          <div style="display: flex; align-items: center; justify-content: space-between; font-size: 11px; color: #64748B; border-top: 1px solid #E2E8F0; padding-top: 6px;">
            <span>Units on standby:</span>
            <span style="font-weight: 700; color: #10B981;">${facility.availableUnits} Ready</span>
          </div>
        </div>
      `, {
        className: 'custom-leaflet-popup',
        offset: [0, -10]
      });

      marker.addTo(map);
      facilityMarkersRef.current[facility.id] = marker;
    });
  }, [facilities, showHospitals, showPolice, showFireStations, mapReady]);

  // Recenter helper
  const handleRecenter = () => {
    if (!mapInstanceRef.current) return;
    mapInstanceRef.current.flyTo(MAP_CENTER, 13, { duration: 0.8 });
  };

  return (
    <div className="relative w-full h-full min-h-[420px] bg-slate-900 overflow-hidden">
      {/* Map DOM Element */}
      <div ref={mapContainerRef} className="w-full h-full" />

      {/* Picking Location Floating Indicator */}
      {isPickingLocation && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[500] bg-blue-600/95 backdrop-blur text-white px-4 py-2 rounded-full shadow-xl flex items-center gap-2 text-xs font-semibold animate-bounce">
          <Navigation className="w-4 h-4" />
          Click anywhere on the map to set incident coordinates
        </div>
      )}

      {/* Map Control Shortcuts (Top Right) */}
      <div className="absolute top-4 right-4 z-[400] flex flex-col gap-2">
        <button
          onClick={handleRecenter}
          className="bg-white/95 hover:bg-white text-slate-800 p-2.5 rounded-lg shadow-md border border-slate-200 transition-colors flex items-center justify-center text-xs font-medium gap-1.5"
          title="Recenter City Command Area"
        >
          <Compass className="w-4 h-4 text-slate-600" />
          <span className="hidden sm:inline">Recenter</span>
        </button>
      </div>

      {/* Map Legend Overlay (Bottom Left) */}
      <div className="absolute bottom-6 left-6 z-[400] bg-white/95 backdrop-blur-sm p-3 rounded-xl border border-slate-200/80 shadow-lg text-xs hidden md:block max-w-[260px]">
        <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2">Live Incident Severity</div>
        <div className="grid grid-cols-2 gap-y-1.5 gap-x-3 text-slate-700">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-red-500 ring-2 ring-red-200 shrink-0"></span>
            <span>Critical (P1)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-amber-500 ring-2 ring-amber-200 shrink-0"></span>
            <span>Medium / Active</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-orange-500 ring-2 ring-orange-200 shrink-0"></span>
            <span>High (P2)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-emerald-200 shrink-0"></span>
            <span>Resolved</span>
          </div>
        </div>
      </div>
    </div>
  );
};
