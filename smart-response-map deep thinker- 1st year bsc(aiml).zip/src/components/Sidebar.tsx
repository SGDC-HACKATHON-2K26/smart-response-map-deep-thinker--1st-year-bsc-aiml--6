import React from 'react';
import { 
  Map, ShieldAlert, Radio, Hospital, HelpCircle, 
  PlusCircle, User, ShieldCheck, Flame, ChevronRight, Menu, X, Database 
} from 'lucide-react';
import { ResponderUser } from '../types';

export type ActiveTab = 'map' | 'incidents' | 'responder' | 'facilities';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenReportModal: () => void;
  onOpenResponderModal: () => void;
  onOpenGuideModal: () => void;
  currentResponder: ResponderUser | null;
  totalIncidents: number;
  pendingCount: number;
  isMobileOpen: boolean;
  setIsMobileOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  onOpenReportModal,
  onOpenResponderModal,
  onOpenGuideModal,
  currentResponder,
  totalIncidents,
  pendingCount,
  isMobileOpen,
  setIsMobileOpen
}) => {
  const navItems = [
    {
      id: 'map' as ActiveTab,
      label: 'Live Incident Map',
      icon: Map,
      badge: totalIncidents
    },
    {
      id: 'incidents' as ActiveTab,
      label: 'Incident Feed & Queue',
      icon: Radio,
      badge: pendingCount > 0 ? `${pendingCount} Pending` : undefined,
      badgeColor: 'bg-amber-500/20 text-amber-300'
    },
    {
      id: 'responder' as ActiveTab,
      label: 'Responder Dashboard',
      icon: ShieldAlert,
      badge: currentResponder ? 'Authenticated' : 'Locked',
      badgeColor: currentResponder ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-700 text-slate-400'
    },
    {
      id: 'facilities' as ActiveTab,
      label: 'Emergency Services',
      icon: Hospital
    }
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div
          onClick={() => setIsMobileOpen(false)}
          className="fixed inset-0 bg-slate-950/70 z-40 lg:hidden"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed lg:static top-0 bottom-0 left-0 z-50 w-64 bg-[#091124] text-slate-200 border-r border-slate-800/80 flex flex-col transition-transform duration-200 ease-in-out ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Brand Header */}
        <div className="p-5 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-md shadow-blue-500/20">
              <Flame className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-sm tracking-tight text-white leading-tight">
                SMART RESPONSE
              </h1>
              <p className="text-[10px] text-blue-400 uppercase tracking-wider font-semibold">
                Open Innovation Map
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsMobileOpen(false)}
            className="lg:hidden text-slate-400 hover:text-white p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Primary Report CTA */}
        <div className="p-4">
          <button
            onClick={() => {
              onOpenReportModal();
              setIsMobileOpen(false);
            }}
            className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-600/25 transition-all"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Report New Incident</span>
          </button>
        </div>

        {/* Main Navigation Links */}
        <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
          <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider px-3 mb-2">
            Operations Navigation
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsMobileOpen(false);
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors ${
                  isActive
                    ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30'
                    : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-blue-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      item.badgeColor || 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Bottom Panel: Responder Info & Laptop Run Guide */}
        <div className="p-3 border-t border-slate-800/80 space-y-2">
          
          {/* Responder Access Widget */}
          <div
            onClick={onOpenResponderModal}
            className="p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 cursor-pointer transition-colors"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className={`w-4 h-4 ${currentResponder ? 'text-emerald-400' : 'text-slate-400'}`} />
                <span className="text-xs font-bold text-white">
                  {currentResponder ? currentResponder.name : 'Responder Auth'}
                </span>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5">
              {currentResponder ? `${currentResponder.role} (${currentResponder.badgeNumber})` : 'Click to unlock responder tools'}
            </p>
          </div>

          {/* Beginner Run Guide CTA */}
          <button
            onClick={() => {
              onOpenGuideModal();
              setIsMobileOpen(false);
            }}
            className="w-full flex items-center justify-between p-2 rounded-lg text-[11px] text-slate-400 hover:text-blue-400 hover:bg-slate-800/50 transition-colors"
          >
            <div className="flex items-center gap-2">
              <HelpCircle className="w-3.5 h-3.5" />
              <span>How to Run on Laptop</span>
            </div>
            <span className="text-[10px] bg-slate-800 px-1.5 py-0.5 rounded font-mono">Guide</span>
          </button>

          {/* Live System Status Indicator */}
          <div className="flex items-center justify-between px-2 pt-1 text-[10px] text-slate-500 border-t border-slate-800/40">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
              <span>Demo Mode Active</span>
            </span>
            <span className="font-mono">v1.0 Hackathon</span>
          </div>
        </div>
      </aside>
    </>
  );
};
