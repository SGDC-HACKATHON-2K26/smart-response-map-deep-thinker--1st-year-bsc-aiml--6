import React from 'react';
import { Incident } from '../types';
import { 
  X, MapPin, Clock, ShieldCheck, AlertTriangle, Flame, 
  Car, Waves, Activity, Sparkles, User, Phone, CheckCircle, 
  ExternalLink, Shield, Layers 
} from 'lucide-react';

interface IncidentDetailsModalProps {
  incident: Incident | null;
  onClose: () => void;
  onOpenResponderCommand: (incident: Incident) => void;
  onFindNearbyServices: (incident: Incident) => void;
}

export const IncidentDetailsModal: React.FC<IncidentDetailsModalProps> = ({
  incident,
  onClose,
  onOpenResponderCommand,
  onFindNearbyServices
}) => {
  if (!incident) return null;

  const formattedDate = new Date(incident.reportedAt).toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });

  return (
    <div className="fixed inset-0 z-[1050] bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150">
        
        {/* Top Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <span className="font-mono text-xs font-bold text-blue-400 bg-slate-800 px-2.5 py-1 rounded-md">
              {incident.reportCode}
            </span>
            <div className="flex items-center gap-2">
              <span className={`text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                incident.isDemo ? 'bg-slate-800 text-slate-300' : 'bg-blue-600 text-white'
              }`}>
                {incident.isDemo ? 'Demo Incident' : 'Live User Report'}
              </span>
              <span className={`text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                incident.status === 'resolved'
                  ? 'bg-emerald-500/20 text-emerald-300'
                  : incident.status === 'ongoing'
                  ? 'bg-orange-500/20 text-orange-300'
                  : 'bg-amber-500/20 text-amber-300'
              }`}>
                {incident.status}
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto text-slate-800">
          
          {/* Main Title & Time */}
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
              <Clock className="w-3.5 h-3.5" />
              <span>Reported: {formattedDate}</span>
              <span>·</span>
              <span className="capitalize font-semibold text-slate-700">{incident.type} Emergency</span>
            </div>
            <h3 className="text-xl font-bold text-slate-900 leading-snug">
              {incident.title}
            </h3>
          </div>

          {/* Photo if present */}
          {incident.imageUrl && (
            <div className="rounded-xl overflow-hidden border border-slate-200 max-h-56 bg-slate-950">
              <img
                src={incident.imageUrl}
                alt={incident.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
          )}

          {/* Description */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs leading-relaxed text-slate-700">
            <span className="font-bold text-slate-900 block mb-1">Incident Description:</span>
            {incident.description}
          </div>

          {/* Smart Priority Box */}
          <div className="border border-slate-200 rounded-xl p-3.5 bg-white">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                <Sparkles className="w-4 h-4 text-blue-600" />
                <span>Smart Priority Classification</span>
              </div>
              <span className={`text-xs font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                incident.priority === 'critical'
                  ? 'bg-red-100 text-red-800'
                  : incident.priority === 'high'
                  ? 'bg-orange-100 text-orange-800'
                  : incident.priority === 'medium'
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-emerald-100 text-emerald-800'
              }`}>
                Priority: {incident.priority}
              </span>
            </div>
            <div className="text-[11px] text-slate-600 space-y-1">
              {incident.priorityReasons.map((reason, idx) => (
                <div key={idx} className="flex items-start gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400 mt-1.5 shrink-0"></span>
                  <span>{reason}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Location & Contact Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="border border-slate-200 rounded-xl p-3 bg-slate-50/50">
              <div className="flex items-center gap-1.5 font-bold text-slate-700 mb-1">
                <MapPin className="w-3.5 h-3.5 text-blue-600" />
                <span>Location</span>
              </div>
              <div className="text-slate-800 font-medium mb-1">{incident.location.address}</div>
              <div className="text-[11px] text-slate-500 font-mono-numbers">
                Lat: {incident.location.lat.toFixed(4)}, Lng: {incident.location.lng.toFixed(4)}
              </div>
            </div>

            <div className="border border-slate-200 rounded-xl p-3 bg-slate-50/50">
              <div className="flex items-center gap-1.5 font-bold text-slate-700 mb-1">
                <User className="w-3.5 h-3.5 text-blue-600" />
                <span>Reporter Details</span>
              </div>
              <div className="text-slate-800 font-medium">{incident.reporterName || 'Anonymous Citizen'}</div>
              {incident.reporterContact && (
                <div className="text-[11px] text-slate-500 mt-1">
                  📞 {incident.reporterContact}
                </div>
              )}
            </div>
          </div>

          {/* Assigned Units & Verification */}
          <div className="border border-slate-200 rounded-xl p-3 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div>
              <span className="text-[11px] text-slate-500 font-bold uppercase tracking-wider block">Assigned Unit</span>
              <span className="font-semibold text-slate-900">
                {incident.assignedUnit || 'No unit assigned yet'}
              </span>
            </div>
            <div>
              <span className="text-[11px] text-slate-500 font-bold uppercase tracking-wider block">Verification</span>
              <span className={`font-semibold capitalize ${
                incident.verificationStatus === 'verified'
                  ? 'text-emerald-600'
                  : incident.verificationStatus === 'false_alarm'
                  ? 'text-red-600'
                  : 'text-amber-600'
              }`}>
                {incident.verificationStatus.replace('_', ' ')}
              </span>
            </div>
          </div>

          {/* Duplicate Linkage Banner if flagged */}
          {incident.duplicateCount && incident.duplicateCount > 0 ? (
            <div className="bg-amber-50 border border-amber-300 rounded-xl p-3 text-xs text-amber-900 flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-600 shrink-0" />
              <span>
                <strong>{incident.duplicateCount} duplicate citizen reports</strong> have been consolidated into this primary incident.
              </span>
            </div>
          ) : null}

          {/* Official Responder Timeline Logs */}
          {incident.responderNotes && incident.responderNotes.length > 0 && (
            <div>
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                Responder Operational Log
              </h4>
              <div className="space-y-2">
                {incident.responderNotes.map((log) => (
                  <div key={log.id} className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-xs">
                    <div className="flex justify-between text-[11px] text-slate-500 mb-1">
                      <span className="font-bold text-slate-800">{log.responderName} ({log.badgeNumber})</span>
                      <span>{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    <div className="font-semibold text-blue-700 text-[11px]">{log.action}</div>
                    <p className="text-slate-600 mt-0.5">{log.note}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Action CTAs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <button
              onClick={() => {
                onFindNearbyServices(incident);
                onClose();
              }}
              className="w-full bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold py-2.5 px-4 rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <span>🏥 Check Nearest Facilities</span>
            </button>
            <button
              onClick={() => {
                onOpenResponderCommand(incident);
                onClose();
              }}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 px-4 rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5 shadow"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Responder Action Command</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
