import React, { useState } from 'react';
import { 
  X, Laptop, Flame, Database, Key, Shield, 
  CheckCircle2, Terminal, Copy, Check, Sparkles, AlertCircle 
} from 'lucide-react';
import { CustomFirebaseConfig, incidentService } from '../../services/incidentStorage';

interface BeginnerGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  onResetDemoData: () => void;
}

export const BeginnerGuideModal: React.FC<BeginnerGuideModalProps> = ({
  isOpen,
  onClose,
  onResetDemoData
}) => {
  const [activeTab, setActiveTab] = useState<'laptop' | 'firebase' | 'hackathon'>('laptop');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Custom Firebase Settings Form state
  const existingConfig = incidentService.getFirebaseConfig();
  const [apiKey, setApiKey] = useState(existingConfig?.apiKey || '');
  const [projectId, setProjectId] = useState(existingConfig?.projectId || '');
  const [authDomain, setAuthDomain] = useState(existingConfig?.authDomain || '');
  const [storageBucket, setStorageBucket] = useState(existingConfig?.storageBucket || '');
  const [firebaseSaved, setFirebaseSaved] = useState(false);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(id);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const handleSaveFirebase = (e: React.FormEvent) => {
    e.preventDefault();
    incidentService.saveFirebaseConfig({
      apiKey,
      projectId,
      authDomain,
      storageBucket,
      enabled: Boolean(apiKey && projectId)
    });
    setFirebaseSaved(true);
    setTimeout(() => setFirebaseSaved(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-[1200] bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-2xl w-full overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
              <Laptop className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white leading-tight">Beginner's Guide & Project Instructions</h3>
              <p className="text-xs text-slate-400">Easy instructions to run Smart Response Map on your laptop</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-6 pt-3 gap-2">
          <button
            onClick={() => setActiveTab('laptop')}
            className={`pb-3 px-3 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'laptop'
                ? 'border-blue-600 text-blue-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            1. Run on Laptop
          </button>
          <button
            onClick={() => setActiveTab('firebase')}
            className={`pb-3 px-3 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'firebase'
                ? 'border-blue-600 text-blue-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            2. Firebase & Demo Mode
          </button>
          <button
            onClick={() => setActiveTab('hackathon')}
            className={`pb-3 px-3 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'hackathon'
                ? 'border-blue-600 text-blue-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            3. Hackathon Features
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 max-h-[75vh] overflow-y-auto space-y-5 text-slate-800 text-xs">
          
          {/* TAB 1: HOW TO RUN ON LAPTOP */}
          {activeTab === 'laptop' && (
            <div className="space-y-4">
              <div className="bg-blue-50/70 border border-blue-200 rounded-xl p-3.5 flex items-start gap-3">
                <Terminal className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                <p className="text-slate-700 leading-relaxed">
                  Hi! Running this website on your laptop is super easy. You only need <strong>Node.js (version 18 or higher)</strong> installed on your Windows, Mac, or Linux computer.
                </p>
              </div>

              {/* Step 1 */}
              <div className="border border-slate-200 rounded-xl p-4 space-y-2 bg-white">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-sm">Step 1: Open Terminal in Project Folder</span>
                  <button
                    onClick={() => copyToClipboard('cd smart-response-map', 'cd')}
                    className="text-slate-500 hover:text-blue-600 flex items-center gap-1 font-semibold text-[11px]"
                  >
                    {copiedCode === 'cd' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCode === 'cd' ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <p className="text-slate-600">
                  Open your computer's terminal (or VS Code terminal) and navigate into the project directory:
                </p>
                <div className="bg-slate-900 text-slate-100 p-3 rounded-lg font-mono text-[11px] select-all">
                  cd smart-response-map
                </div>
              </div>

              {/* Step 2 */}
              <div className="border border-slate-200 rounded-xl p-4 space-y-2 bg-white">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-sm">Step 2: Install Dependencies</span>
                  <button
                    onClick={() => copyToClipboard('npm install', 'install')}
                    className="text-slate-500 hover:text-blue-600 flex items-center gap-1 font-semibold text-[11px]"
                  >
                    {copiedCode === 'install' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCode === 'install' ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <p className="text-slate-600">
                  Run this command once. It downloads React, Leaflet, and Tailwind CSS:
                </p>
                <div className="bg-slate-900 text-slate-100 p-3 rounded-lg font-mono text-[11px] select-all">
                  npm install
                </div>
              </div>

              {/* Step 3 */}
              <div className="border border-slate-200 rounded-xl p-4 space-y-2 bg-white">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 text-sm">Step 3: Start Development Server</span>
                  <button
                    onClick={() => copyToClipboard('npm run dev', 'dev')}
                    className="text-slate-500 hover:text-blue-600 flex items-center gap-1 font-semibold text-[11px]"
                  >
                    {copiedCode === 'dev' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCode === 'dev' ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <p className="text-slate-600">
                  Start the local development server:
                </p>
                <div className="bg-slate-900 text-emerald-400 p-3 rounded-lg font-mono text-[11px] select-all">
                  npm run dev
                </div>
                <p className="text-slate-600 pt-1">
                  Then open your web browser and visit: <strong className="text-blue-600">http://localhost:3000</strong>
                </p>
              </div>
            </div>
          )}

          {/* TAB 2: FIREBASE & DEMO MODE */}
          {activeTab === 'firebase' && (
            <div className="space-y-4">
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 text-slate-700">
                <div className="font-bold text-emerald-900 mb-1 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Demo Mode is Active & Fully Functional</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  The app automatically runs in <strong>Interactive Demo Mode</strong> with pre-populated emergency incidents, responder verification, duplicate detection, and real-time multi-tab synchronization! You do <strong>not</strong> need Firebase credentials to run or demonstrate all features during the hackathon.
                </p>
              </div>

              {/* Reset Demo Data Button */}
              <div className="border border-slate-200 rounded-xl p-3.5 bg-slate-50 flex items-center justify-between">
                <div>
                  <div className="font-bold text-slate-900">Reset Demo Incidents</div>
                  <div className="text-slate-500 text-[11px]">Restore original 7 hackathon sample incidents</div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onResetDemoData();
                    alert('Sample incidents reloaded successfully!');
                  }}
                  className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold px-3 py-1.5 rounded-lg text-xs transition-colors"
                >
                  Reload Demo Data
                </button>
              </div>

              {/* Optional Custom Firebase Config Input */}
              <form onSubmit={handleSaveFirebase} className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
                <div className="flex items-center gap-1.5 font-bold text-slate-900">
                  <Database className="w-4 h-4 text-orange-500" />
                  <span>Optional: Connect Custom Firebase Project</span>
                </div>
                <p className="text-slate-500 text-[11px]">
                  If you have a Google Firebase console project, you can paste its web configuration parameters here to enable cloud persistence:
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 text-[11px] font-semibold mb-1">API Key</label>
                    <input
                      type="text"
                      placeholder="AIzaSy..."
                      value={apiKey}
                      onChange={(e) => setApiKey(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 text-[11px] font-semibold mb-1">Project ID</label>
                    <input
                      type="text"
                      placeholder="smart-response-map"
                      value={projectId}
                      onChange={(e) => setProjectId(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 text-[11px] font-semibold mb-1">Auth Domain</label>
                    <input
                      type="text"
                      placeholder="smart-response.firebaseapp.com"
                      value={authDomain}
                      onChange={(e) => setAuthDomain(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 text-[11px] font-semibold mb-1">Storage Bucket</label>
                    <input
                      type="text"
                      placeholder="smart-response.appspot.com"
                      value={storageBucket}
                      onChange={(e) => setStorageBucket(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <button
                    type="submit"
                    className="bg-slate-900 hover:bg-slate-800 text-white font-semibold px-4 py-2 rounded-lg text-xs transition-colors"
                  >
                    Save Firebase Credentials
                  </button>
                  {firebaseSaved && (
                    <span className="text-emerald-600 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Saved!
                    </span>
                  )}
                </div>
              </form>
            </div>
          )}

          {/* TAB 3: HACKATHON INNOVATION HIGHLIGHTS */}
          {activeTab === 'hackathon' && (
            <div className="space-y-3">
              <div className="border border-slate-200 rounded-xl p-3.5 bg-white space-y-1.5">
                <div className="font-bold text-slate-900 flex items-center gap-1.5 text-sm">
                  <Sparkles className="w-4 h-4 text-blue-600" />
                  <span>1. Smart Priority Engine (AI / Rule-based)</span>
                </div>
                <p className="text-slate-600 leading-relaxed text-[11px]">
                  Analyzes natural language incident descriptions for high-risk markers ("trapped", "unconscious", "flames spreading", "cardiac", "gas leak") and automatically assigns Priority 1 (Critical) through Priority 4 (Low) with explainable reasoning tags so dispatchers know <em>why</em> an alert was elevated.
                </p>
              </div>

              <div className="border border-slate-200 rounded-xl p-3.5 bg-white space-y-1.5">
                <div className="font-bold text-slate-900 flex items-center gap-1.5 text-sm">
                  <Shield className="w-4 h-4 text-amber-600" />
                  <span>2. Spatial Duplicate Detection</span>
                </div>
                <p className="text-slate-600 leading-relaxed text-[11px]">
                  During major disasters, hundreds of citizens report the same fire or accident. Using spatial Haversine trigonometry (within 600m) and temporal proximity (within 3 hours), the system flags potential duplicate reports, computes match confidence percentages, and prevents dispatcher overwhelm.
                </p>
              </div>

              <div className="border border-slate-200 rounded-xl p-3.5 bg-white space-y-1.5">
                <div className="font-bold text-slate-900 flex items-center gap-1.5 text-sm">
                  <Key className="w-4 h-4 text-emerald-600" />
                  <span>3. Authorized Responder Security</span>
                </div>
                <p className="text-slate-600 leading-relaxed text-[11px]">
                  Authorized personnel authenticate with designated badge identities (Fire Chief, Lead Paramedic, Police Commander, Chief Dispatcher) and passcode (PIN: <strong>1234</strong>) to verify civilian reports, dismiss false alarms, assign vehicles, and log operational action timestamps.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
