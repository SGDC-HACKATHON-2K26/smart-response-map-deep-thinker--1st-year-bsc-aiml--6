import React, { useState, useEffect } from 'react';
import { Incident, IncidentPriority, IncidentType, LocationCoords } from '../../types';
import { calculateSmartPriority } from '../../services/smartPriority';
import { detectPotentialDuplicate } from '../../services/duplicateDetector';
import { 
  X, AlertTriangle, Flame, Car, Waves, Activity, 
  MapPin, Upload, Camera, Sparkles, AlertCircle, CheckCircle2, ChevronRight 
} from 'lucide-react';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (newIncident: Incident) => void;
  existingIncidents: Incident[];
  onStartMapPick: () => void;
  pickedCoords: { lat: number; lng: number } | null;
}

const SAMPLE_PHOTOS = [
  { label: 'Vehicle Crash', url: 'https://images.unsplash.com/photo-1542385151-efd9000785a0?w=600&auto=format&fit=crop&q=80' },
  { label: 'Fire & Smoke', url: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=600&auto=format&fit=crop&q=80' },
  { label: 'Water Flooding', url: 'https://images.unsplash.com/photo-1547683905-f686c993aae5?w=600&auto=format&fit=crop&q=80' }
];

export const ReportModal: React.FC<ReportModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  existingIncidents,
  onStartMapPick,
  pickedCoords
}) => {
  const [type, setType] = useState<IncidentType>('accident');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [address, setAddress] = useState('');
  const [lat, setLat] = useState(37.7749);
  const [lng, setLng] = useState(-122.4194);
  const [reporterName, setReporterName] = useState('');
  const [reporterContact, setReporterContact] = useState('');
  const [imagePreview, setImagePreview] = useState<string>('');
  const [gpsLoading, setGpsLoading] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [submittedCode, setSubmittedCode] = useState<string | null>(null);

  // Sync picked coords from map if user clicked on map
  useEffect(() => {
    if (pickedCoords) {
      setLat(pickedCoords.lat);
      setLng(pickedCoords.lng);
      if (!address || address.includes('Lat:')) {
        setAddress(`Pinned Location (Lat: ${pickedCoords.lat}, Lng: ${pickedCoords.lng})`);
      }
    }
  }, [pickedCoords]);

  // Real-time Smart Priority calculation
  const smartPriorityResult = calculateSmartPriority(type, description);

  // Real-time Duplicate Detection check
  const duplicateResult = detectPotentialDuplicate(
    type,
    { lat, lng, address },
    existingIncidents
  );

  // Auto GPS Location Handler
  const handleDetectGps = () => {
    setGpsLoading(true);
    setGpsError(null);
    if (!navigator.geolocation) {
      setGpsError('Geolocation is not supported by your browser.');
      setGpsLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const userLat = Number(pos.coords.latitude.toFixed(5));
        const userLng = Number(pos.coords.longitude.toFixed(5));
        setLat(userLat);
        setLng(userLng);
        setAddress(`GPS Position (Lat: ${userLat}, Lng: ${userLng})`);
        setGpsLoading(false);
      },
      (err) => {
        // Fallback for permission denied in preview iframe
        console.warn('GPS location permission denied or timed out:', err);
        setGpsError('Using default Civic Center coordinates (permission unavailable)');
        setLat(37.7749);
        setLng(-122.4194);
        setAddress('Civic Center Plaza, Downtown');
        setGpsLoading(false);
      },
      { timeout: 7000 }
    );
  };

  // Image file handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setImagePreview(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    const reportNum = Math.floor(1000 + Math.random() * 9000);
    const code = `SRM-${reportNum}`;

    const newIncident: Incident = {
      id: `inc-live-${Date.now()}`,
      reportCode: code,
      type,
      title: title.trim(),
      description: description.trim(),
      location: {
        lat,
        lng,
        address: address.trim() || `Civic Coordinates (${lat.toFixed(4)}, ${lng.toFixed(4)})`
      },
      priority: smartPriorityResult.suggestedPriority,
      priorityReasons: smartPriorityResult.reasons,
      status: 'pending',
      verificationStatus: 'unverified',
      reportedAt: Date.now(),
      updatedAt: Date.now(),
      reporterName: reporterName.trim() || 'Anonymous Civilian',
      reporterContact: reporterContact.trim() || undefined,
      imageUrl: imagePreview || undefined,
      isDemo: false, // LIVE REPORT submitted by user
      duplicateOfId: duplicateResult.isPotentialDuplicate && duplicateResult.matchedIncident
        ? duplicateResult.matchedIncident.id
        : undefined,
      duplicateScore: duplicateResult.isPotentialDuplicate ? duplicateResult.confidenceScore : undefined
    };

    onSubmit(newIncident);
    setSubmittedCode(code);
  };

  const handleResetAndClose = () => {
    setSubmittedCode(null);
    setTitle('');
    setDescription('');
    setAddress('');
    setImagePreview('');
    setReporterName('');
    setReporterContact('');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[1000] bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-xl w-full overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
          <div>
            <span className="text-xs uppercase tracking-wider font-semibold text-blue-400">Emergency Dispatch Ingestion</span>
            <h2 className="text-lg font-bold text-white">Quick Incident Report</h2>
          </div>
          <button
            onClick={handleResetAndClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submittedCode ? (
          /* Submission Success State */
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <span className="text-xs font-semibold text-emerald-600 uppercase tracking-wider">Report Dispatched Live</span>
            <h3 className="text-2xl font-bold text-slate-900 mt-1 mb-2">Reference Code: {submittedCode}</h3>
            <p className="text-slate-600 text-sm max-w-md mx-auto mb-6">
              Your emergency report has been saved to the database and broadcasted onto the live map. Emergency responders will verify and review it momentarily.
            </p>
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-left mb-6 max-w-md mx-auto text-xs text-slate-700 space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Incident Type:</span>
                <span className="font-semibold capitalize text-slate-900">{type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Assigned Priority:</span>
                <span className="font-semibold uppercase text-red-600">{smartPriorityResult.suggestedPriority}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Status:</span>
                <span className="font-semibold text-amber-600">Pending Responder Review</span>
              </div>
            </div>
            <button
              onClick={handleResetAndClose}
              className="w-full max-w-md bg-slate-900 hover:bg-slate-800 text-white py-3 px-6 rounded-xl font-semibold text-sm transition-colors shadow-md"
            >
              View on Live Incident Map
            </button>
          </div>
        ) : (
          /* Input Form */
          <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[82vh] overflow-y-auto">
            
            {/* 1. Incident Type Selector */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                1. Select Incident Type
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { id: 'accident', label: 'Accident', icon: Car, color: 'hover:border-orange-500' },
                  { id: 'fire', label: 'Fire & Smoke', icon: Flame, color: 'hover:border-red-500' },
                  { id: 'flood', label: 'Flood / Water', icon: Waves, color: 'hover:border-blue-500' },
                  { id: 'medical', label: 'Medical Alert', icon: Activity, color: 'hover:border-rose-500' },
                  { id: 'hazard', label: 'Hazard / Leak', icon: AlertTriangle, color: 'hover:border-amber-500' },
                  { id: 'other', label: 'Other Urgent', icon: AlertCircle, color: 'hover:border-purple-500' }
                ].map((item) => {
                  const Icon = item.icon;
                  const isSelected = type === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setType(item.id as IncidentType)}
                      className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs font-semibold transition-all text-left ${
                        isSelected
                          ? 'border-blue-600 bg-blue-50 text-blue-900 shadow-sm ring-1 ring-blue-600'
                          : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <Icon className={`w-4 h-4 ${isSelected ? 'text-blue-600' : 'text-slate-500'}`} />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 2. Title & Description */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  2. Incident Summary
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 2-Car Crash at Intersection / Commercial Kitchen Smoke"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Detailed Description
                  </label>
                  <span className="text-[11px] text-slate-400">Describe injuries, smoke, trapped people</span>
                </div>
                <textarea
                  required
                  rows={3}
                  placeholder="Describe what happened, whether people are trapped or injured, flames visible, road blocked..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900"
                />
              </div>
            </div>

            {/* Smart Priority Assistant Live Banner */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
                  <Sparkles className="w-4 h-4 text-blue-600" />
                  Smart Priority Suggestion
                </div>
                <span className={`text-xs font-bold px-2.5 py-0.5 rounded-md uppercase tracking-wider ${
                  smartPriorityResult.suggestedPriority === 'critical'
                    ? 'bg-red-100 text-red-700'
                    : smartPriorityResult.suggestedPriority === 'high'
                    ? 'bg-orange-100 text-orange-700'
                    : smartPriorityResult.suggestedPriority === 'medium'
                    ? 'bg-amber-100 text-amber-700'
                    : 'bg-emerald-100 text-emerald-700'
                }`}>
                  {smartPriorityResult.suggestedPriority} (Score: {smartPriorityResult.severityScore}/100)
                </span>
              </div>
              <div className="text-[11px] text-slate-600 space-y-0.5">
                {smartPriorityResult.reasons.map((reason, idx) => (
                  <div key={idx} className="flex items-center gap-1.5">
                    <span className="w-1 h-1 rounded-full bg-slate-400"></span>
                    <span>{reason}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* 3. Location Picker */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                3. Incident Location
              </label>
              <div className="flex gap-2 mb-2">
                <input
                  type="text"
                  required
                  placeholder="Street address or landmark..."
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent text-slate-900"
                />
                <button
                  type="button"
                  onClick={handleDetectGps}
                  disabled={gpsLoading}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-800 px-3 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shrink-0"
                  title="Detect GPS from device"
                >
                  <MapPin className="w-4 h-4 text-blue-600" />
                  <span>{gpsLoading ? 'Locating...' : 'Use GPS'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onStartMapPick();
                    onClose();
                  }}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors shrink-0"
                >
                  <span>Pick on Map</span>
                </button>
              </div>

              {gpsError && (
                <p className="text-[11px] text-amber-600 mt-1">{gpsError}</p>
              )}

              <div className="text-[11px] text-slate-500 font-mono-numbers">
                Coordinates: {lat.toFixed(4)}, {lng.toFixed(4)}
              </div>
            </div>

            {/* Duplicate Detection Alert Warning */}
            {duplicateResult.isPotentialDuplicate && duplicateResult.matchedIncident && (
              <div className="bg-amber-50 border border-amber-300 rounded-xl p-3.5 text-xs text-amber-900">
                <div className="flex items-center gap-2 font-bold mb-1">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>Possible Duplicate Report Detected ({duplicateResult.confidenceScore}% Proximity Match)</span>
                </div>
                <p className="text-amber-800 text-[11px] mb-2">
                  Another similar report <strong>#{duplicateResult.matchedIncident.reportCode} ("{duplicateResult.matchedIncident.title}")</strong> was reported approx. {duplicateResult.distanceMeters}m away ({duplicateResult.timeDiffMinutes} min ago).
                </p>
                <span className="text-[10px] text-amber-700 italic">
                  Note: You may still submit this report. It will be automatically linked to the primary incident for responder deduplication.
                </span>
              </div>
            )}

            {/* 4. Optional Photo Upload */}
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                4. Incident Photo (Optional)
              </label>
              
              {imagePreview ? (
                <div className="relative rounded-xl overflow-hidden border border-slate-200 h-36 bg-slate-900 mb-2">
                  <img
                    src={imagePreview}
                    alt="Incident preview"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <button
                    type="button"
                    onClick={() => setImagePreview('')}
                    className="absolute top-2 right-2 bg-slate-900/80 text-white p-1 rounded-full hover:bg-red-600 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <label className="border-2 border-dashed border-slate-200 hover:border-blue-500 rounded-xl p-4 flex flex-col items-center justify-center cursor-pointer transition-colors bg-slate-50/50">
                    <Camera className="w-6 h-6 text-slate-400 mb-1" />
                    <span className="text-xs font-semibold text-slate-700">Upload photo from device</span>
                    <span className="text-[10px] text-slate-400">PNG, JPG up to 10MB</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>

                  {/* Preset Quick Samples for Testing */}
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold text-slate-400 uppercase">Or quick sample:</span>
                    <div className="flex gap-1.5 flex-wrap">
                      {SAMPLE_PHOTOS.map((sample, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setImagePreview(sample.url)}
                          className="text-[10px] px-2 py-0.5 rounded bg-slate-100 hover:bg-slate-200 text-slate-600 font-medium transition-colors"
                        >
                          +{sample.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* 5. Reporter Info (Optional) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1 border-t border-slate-100">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">
                  Reporter Name (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Jane Doe"
                  value={reporterName}
                  onChange={(e) => setReporterName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-600"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">
                  Contact Phone (Optional)
                </label>
                <input
                  type="tel"
                  placeholder="e.g. +1 555-019-8800"
                  value={reporterContact}
                  onChange={(e) => setReporterContact(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-600"
                />
              </div>
            </div>

            {/* Submit CTA */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-xl shadow-lg shadow-blue-500/20 transition-all flex items-center justify-center gap-2 text-sm"
              >
                <span>Submit Emergency Report</span>
                <ChevronRight className="w-4 h-4" />
              </button>
              <p className="text-center text-[11px] text-slate-400 mt-2">
                All reports are broadcasted instantly to emergency responders with geolocation data.
              </p>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
