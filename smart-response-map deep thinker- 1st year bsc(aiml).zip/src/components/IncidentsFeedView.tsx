import React, { useState } from 'react';
import { Incident, IncidentPriority, IncidentType, IncidentStatus } from '../types';
import { 
  Search, Filter, Flame, Car, Waves, Activity, 
  AlertTriangle, CheckCircle2, Clock, ShieldCheck, MapPin, 
  Layers, ChevronRight, Eye 
} from 'lucide-react';

interface IncidentsFeedViewProps {
  incidents: Incident[];
  onSelectIncident: (incident: Incident) => void;
  onOpenResponderCommand: (incident: Incident) => void;
}

export const IncidentsFeedView: React.FC<IncidentsFeedViewProps> = ({
  incidents,
  onSelectIncident,
  onOpenResponderCommand
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedOrigin, setSelectedOrigin] = useState<'all' | 'live' | 'demo'>('all');

  const filteredIncidents = incidents.filter((inc) => {
    // Search
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const matchText = 
        inc.title.toLowerCase().includes(q) ||
        inc.description.toLowerCase().includes(q) ||
        inc.reportCode.toLowerCase().includes(q) ||
        inc.location.address.toLowerCase().includes(q);
      if (!matchText) return false;
    }

    // Type
    if (selectedType !== 'all' && inc.type !== selectedType) return false;

    // Status
    if (selectedStatus !== 'all' && inc.status !== selectedStatus) return false;

    // Origin (Live vs Demo)
    if (selectedOrigin === 'live' && inc.isDemo) return false;
    if (selectedOrigin === 'demo' && !inc.isDemo) return false;

    return true;
  });

  return (
    <div className="space-y-4">
      {/* Top Search & Filter Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search by title, report code (e.g. SRM-8101), address, or keywords..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-300 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>

          {/* Incident Type Select */}
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
          >
            <option value="all">All Incident Types</option>
            <option value="accident">Accident</option>
            <option value="fire">Fire & Smoke</option>
            <option value="flood">Flood</option>
            <option value="medical">Medical Emergency</option>
            <option value="hazard">Hazard / Leak</option>
            <option value="other">Other</option>
          </select>

          {/* Origin filter (Live vs Demo) */}
          <select
            value={selectedOrigin}
            onChange={(e) => setSelectedOrigin(e.target.value as any)}
            className="px-3 py-2 rounded-xl border border-slate-300 text-xs text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-blue-600"
          >
            <option value="all">All Reports (Live & Demo)</option>
            <option value="live">Live User Submissions</option>
            <option value="demo">Demo Sample Data</option>
          </select>
        </div>

        {/* Status Tabs */}
        <div className="flex items-center gap-1.5 flex-wrap pt-1 border-t border-slate-100">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mr-1">Status:</span>
          {[
            { id: 'all', label: 'All Incidents' },
            { id: 'pending', label: 'Pending Review' },
            { id: 'ongoing', label: 'Ongoing / Responding' },
            { id: 'resolved', label: 'Resolved' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedStatus(tab.id)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                selectedStatus === tab.id
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
          <span className="ml-auto text-xs text-slate-500 font-mono-numbers">
            Showing {filteredIncidents.length} of {incidents.length}
          </span>
        </div>
      </div>

      {/* Incidents List / Table */}
      {filteredIncidents.length === 0 ? (
        <div className="bg-white p-12 rounded-xl border border-slate-200 text-center text-slate-500">
          <AlertTriangle className="w-8 h-8 text-slate-400 mx-auto mb-2" />
          <h4 className="font-bold text-sm text-slate-700">No matching incidents found</h4>
          <p className="text-xs text-slate-500 mt-1">Try loosening your search filters or status criteria.</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filteredIncidents.map((incident) => {
            const isPending = incident.status === 'pending';
            const isOngoing = incident.status === 'ongoing';
            const isResolved = incident.status === 'resolved';

            return (
              <div
                key={incident.id}
                onClick={() => onSelectIncident(incident)}
                className="bg-white p-4 rounded-xl border border-slate-200 hover:border-blue-400 hover:shadow-md transition-all cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-3"
              >
                {/* Left: Code, Priority, Title, Location */}
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-xs font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                      {incident.reportCode}
                    </span>

                    {/* Live vs Demo tag */}
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                      incident.isDemo ? 'bg-slate-100 text-slate-500' : 'bg-blue-100 text-blue-700 font-bold'
                    }`}>
                      {incident.isDemo ? 'Demo Data' : 'Live Report'}
                    </span>

                    {/* Priority */}
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                      incident.priority === 'critical'
                        ? 'bg-red-100 text-red-700'
                        : incident.priority === 'high'
                        ? 'bg-orange-100 text-orange-700'
                        : incident.priority === 'medium'
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-emerald-100 text-emerald-700'
                    }`}>
                      {incident.priority}
                    </span>

                    {/* Status */}
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                      isResolved
                        ? 'bg-emerald-100 text-emerald-700'
                        : isOngoing
                        ? 'bg-orange-100 text-orange-700'
                        : 'bg-amber-100 text-amber-700'
                    }`}>
                      {incident.status}
                    </span>

                    {/* Duplicate Flag */}
                    {incident.duplicateCount && incident.duplicateCount > 0 ? (
                      <span className="text-[10px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded flex items-center gap-1 border border-amber-200">
                        <Layers className="w-3 h-3" />
                        {incident.duplicateCount} merged duplicates
                      </span>
                    ) : null}
                  </div>

                  <h3 className="font-bold text-sm text-slate-900">
                    {incident.title}
                  </h3>

                  <p className="text-xs text-slate-600 line-clamp-1">
                    {incident.description}
                  </p>

                  <div className="flex items-center gap-3 text-[11px] text-slate-500 flex-wrap pt-0.5">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span>{incident.location.address}</span>
                    </span>
                    <span>·</span>
                    <span className="font-mono-numbers">
                      {new Date(incident.reportedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    {incident.assignedUnit && (
                      <>
                        <span>·</span>
                        <span className="text-blue-600 font-semibold">{incident.assignedUnit}</span>
                      </>
                    )}
                  </div>
                </div>

                {/* Right: Actions */}
                <div className="flex items-center gap-2 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-slate-100">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectIncident(incident);
                    }}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Details</span>
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenResponderCommand(incident);
                    }}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors shadow-sm"
                  >
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Responder</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
