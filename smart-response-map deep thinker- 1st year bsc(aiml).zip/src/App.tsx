/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Sidebar, ActiveTab } from './components/Sidebar';
import { OverviewStats } from './components/Dashboard/OverviewStats';
import { IncidentMap } from './components/Map/IncidentMap';
import { ReportModal } from './components/IncidentForm/ReportModal';
import { ResponderConsoleModal } from './components/Responder/ResponderConsoleModal';
import { IncidentDetailsModal } from './components/IncidentDetailsModal';
import { NearbyServicesList } from './components/Facilities/NearbyServicesList';
import { IncidentsFeedView } from './components/IncidentsFeedView';
import { BeginnerGuideModal } from './components/Instructions/BeginnerGuideModal';
import { EMERGENCY_FACILITIES } from './data/initialData';
import { Incident, IncidentStatus, ResponderUser, EmergencyFacility } from './types';
import { incidentService } from './services/incidentStorage';
import { 
  Menu, Bell, Plus, ShieldCheck, MapPin, 
  HelpCircle, Compass, Radio, CheckCircle2, AlertTriangle, Hospital 
} from 'lucide-react';

export default function App() {
  const [incidents, setIncidents] = useState<Incident[]>([]);
  const [facilities] = useState<EmergencyFacility[]>(EMERGENCY_FACILITIES);
  const [activeTab, setActiveTab] = useState<ActiveTab>('map');
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);

  // Modals state
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isResponderModalOpen, setIsResponderModalOpen] = useState(false);
  const [isGuideModalOpen, setIsGuideModalOpen] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);

  // Responder state
  const [currentResponder, setCurrentResponder] = useState<ResponderUser | null>(null);
  const [responderTargetIncident, setResponderTargetIncident] = useState<Incident | null>(null);

  // Map filters & picking
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');
  const [isPickingLocation, setIsPickingLocation] = useState(false);
  const [pickedCoords, setPickedCoords] = useState<{ lat: number; lng: number } | null>(null);

  // Facility layer toggles
  const [showHospitals, setShowHospitals] = useState(true);
  const [showPolice, setShowPolice] = useState(true);
  const [showFireStations, setShowFireStations] = useState(true);

  // Mobile menu
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Notification toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Subscribe to real-time incident storage
  useEffect(() => {
    const unsubscribe = incidentService.subscribe((updated) => {
      setIncidents(updated);
    });
    return () => unsubscribe();
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Handlers
  const handleCreateIncident = (newIncident: Incident) => {
    incidentService.addIncident(newIncident);
    setSelectedIncident(newIncident);
    setPickedCoords(null);
    setIsPickingLocation(false);
    showToast(`🚨 Incident #${newIncident.reportCode} reported live and pinned to map!`);
  };

  const handleUpdateStatus = (
    incidentId: string,
    status: IncidentStatus,
    assignedUnit?: string,
    note?: string
  ) => {
    const responderLog = note && currentResponder ? {
      id: 'log-' + Date.now(),
      timestamp: Date.now(),
      responderName: currentResponder.name,
      badgeNumber: currentResponder.badgeNumber,
      action: `Status updated to ${status.toUpperCase()}`,
      note
    } : undefined;

    incidentService.updateIncidentStatus(incidentId, status, assignedUnit, responderLog);
    showToast(`Status updated to ${status.toUpperCase()} for incident`);
  };

  const handleVerify = (incidentId: string, isVerified: boolean, note: string) => {
    if (!currentResponder) return;
    incidentService.updateVerification(
      incidentId,
      isVerified ? 'verified' : 'false_alarm',
      currentResponder.name,
      currentResponder.badgeNumber,
      note
    );
    showToast(isVerified ? 'Incident verified as legitimate' : 'Incident marked false alarm / dismissed');
  };

  const handleOpenResponderForIncident = (inc: Incident) => {
    setResponderTargetIncident(inc);
    setIsResponderModalOpen(true);
  };

  const handleSelectIncident = (inc: Incident) => {
    setSelectedIncident(inc);
    setIsDetailsModalOpen(true);
  };

  const handleFindNearbyServices = (inc: Incident) => {
    setSelectedIncident(inc);
    setActiveTab('facilities');
  };

  const pendingCount = incidents.filter((i) => i.status === 'pending').length;

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-100 font-sans text-slate-900">
      
      {/* Dark Blue Sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenReportModal={() => setIsReportModalOpen(true)}
        onOpenResponderModal={() => {
          setResponderTargetIncident(selectedIncident || incidents[0] || null);
          setIsResponderModalOpen(true);
        }}
        onOpenGuideModal={() => setIsGuideModalOpen(true)}
        currentResponder={currentResponder}
        totalIncidents={incidents.length}
        pendingCount={pendingCount}
        isMobileOpen={isMobileMenuOpen}
        setIsMobileOpen={setIsMobileMenuOpen}
      />

      {/* Main Content Workspace */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        
        {/* Top Bar Contract (3 zones: Brand/Breadcrumb, Controls, Primary Actions) */}
        <header className="h-14 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between gap-4 shrink-0 z-20">
          
          {/* Zone 1: Mobile toggle & Breadcrumbs */}
          <div className="flex items-center gap-3 min-w-0">
            <button
              onClick={() => setIsMobileMenuOpen(true)}
              className="lg:hidden p-1.5 rounded-lg text-slate-600 hover:bg-slate-100"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 truncate">
              <span className="text-slate-900 font-bold hidden sm:inline">Smart Response Map</span>
              <span className="text-slate-300 hidden sm:inline">/</span>
              <span className="text-blue-600 uppercase tracking-wider text-[11px] font-bold">
                {activeTab === 'map' && 'Live Incident Command Map'}
                {activeTab === 'incidents' && 'Incident Queue & Dispatch Stream'}
                {activeTab === 'responder' && 'Authorized Responder Console'}
                {activeTab === 'facilities' && 'Nearby Emergency Assets'}
              </span>
            </div>
          </div>

          {/* Zone 2: Status Indicator */}
          <div className="hidden md:flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs text-slate-600 bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-lg">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>Real-Time Sync Active</span>
            </div>
            {currentResponder && (
              <div className="flex items-center gap-1.5 text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-lg font-medium">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Responder: {currentResponder.name}</span>
              </div>
            )}
          </div>

          {/* Zone 3: Primary Action buttons */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setIsGuideModalOpen(true)}
              className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap"
            >
              <HelpCircle className="w-3.5 h-3.5 text-slate-500" />
              <span className="hidden sm:inline">Laptop Run Guide</span>
            </button>

            <button
              onClick={() => setIsReportModalOpen(true)}
              className="px-3.5 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors shadow-sm flex items-center gap-1.5 whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              <span>Report Incident</span>
            </button>
          </div>
        </header>

        {/* Real-time Toast Banner */}
        {toastMessage && (
          <div className="bg-slate-900 text-white text-xs px-4 py-2 flex items-center justify-between border-b border-slate-800 animate-in slide-in-from-top-2">
            <div className="flex items-center gap-2">
              <Bell className="w-3.5 h-3.5 text-blue-400" />
              <span>{toastMessage}</span>
            </div>
            <button
              onClick={() => setToastMessage(null)}
              className="text-slate-400 hover:text-white text-[11px]"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Tab View Content */}
        <main className="flex-1 overflow-y-auto p-3 sm:p-5">
          
          {/* TAB 1: LIVE MAP & COMMAND DASHBOARD */}
          {activeTab === 'map' && (
            <div className="space-y-4 h-full flex flex-col">
              {/* Dashboard KPIs */}
              <OverviewStats
                incidents={incidents}
                activeFilter={filterStatus}
                onFilterChange={(st) => setFilterStatus(st)}
              />

              {/* Map Container */}
              <div className="flex-1 min-h-[460px] rounded-2xl overflow-hidden border border-slate-300 shadow-sm relative">
                <IncidentMap
                  incidents={incidents}
                  facilities={facilities}
                  selectedIncident={selectedIncident}
                  onSelectIncident={handleSelectIncident}
                  isPickingLocation={isPickingLocation}
                  pickedCoords={pickedCoords}
                  onPickCoords={(coords) => {
                    setPickedCoords(coords);
                    setIsPickingLocation(false);
                    setIsReportModalOpen(true);
                  }}
                  filterStatus={filterStatus}
                  filterType={filterType}
                  showHospitals={showHospitals}
                  showPolice={showPolice}
                  showFireStations={showFireStations}
                />
              </div>

              {/* Nearby Services Strip under Map */}
              <NearbyServicesList
                facilities={facilities}
                referenceLocation={selectedIncident?.location}
                onFacilityClick={(fac) => {
                  showToast(`Selected ${fac.name} - ${fac.phone}`);
                }}
                showHospitals={showHospitals}
                setShowHospitals={setShowHospitals}
                showPolice={showPolice}
                setShowPolice={setShowPolice}
                showFireStations={showFireStations}
                setShowFireStations={setShowFireStations}
              />
            </div>
          )}

          {/* TAB 2: INCIDENT FEED & DISPATCH STREAM */}
          {activeTab === 'incidents' && (
            <div className="space-y-4">
              <OverviewStats
                incidents={incidents}
                activeFilter={filterStatus}
                onFilterChange={(st) => setFilterStatus(st)}
              />
              <IncidentsFeedView
                incidents={incidents}
                onSelectIncident={handleSelectIncident}
                onOpenResponderCommand={handleOpenResponderForIncident}
              />
            </div>
          )}

          {/* TAB 3: RESPONDER DASHBOARD CONSOLE */}
          {activeTab === 'responder' && (
            <div className="space-y-4">
              <div className="bg-slate-900 text-white p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 border border-slate-800">
                <div>
                  <div className="text-xs uppercase tracking-wider font-semibold text-blue-400">
                    Tactical Dispatch Center
                  </div>
                  <h2 className="text-xl font-bold text-white mt-0.5">
                    Authorized Emergency Responder Console
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Manage civilian reports, verify ground truth, dispatch response units, and resolve active emergencies.
                  </p>
                </div>
                <button
                  onClick={() => {
                    setResponderTargetIncident(selectedIncident || incidents[0] || null);
                    setIsResponderModalOpen(true);
                  }}
                  className="bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 px-5 rounded-xl text-xs transition-colors flex items-center justify-center gap-2 shadow-md shrink-0"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{currentResponder ? 'Open Command Panel' : 'Authenticate Responder'}</span>
                </button>
              </div>

              <IncidentsFeedView
                incidents={incidents}
                onSelectIncident={handleSelectIncident}
                onOpenResponderCommand={handleOpenResponderForIncident}
              />
            </div>
          )}

          {/* TAB 4: EMERGENCY SERVICES DIRECTORY */}
          {activeTab === 'facilities' && (
            <div className="space-y-4">
              <NearbyServicesList
                facilities={facilities}
                referenceLocation={selectedIncident?.location}
                onFacilityClick={(fac) => {
                  showToast(`Selected ${fac.name} - ${fac.phone}`);
                }}
                showHospitals={showHospitals}
                setShowHospitals={setShowHospitals}
                showPolice={showPolice}
                setShowPolice={setShowPolice}
                showFireStations={showFireStations}
                setShowFireStations={setShowFireStations}
              />

              {/* Facility Map View */}
              <div className="h-[420px] rounded-2xl overflow-hidden border border-slate-300 shadow-sm relative">
                <IncidentMap
                  incidents={incidents}
                  facilities={facilities}
                  selectedIncident={selectedIncident}
                  onSelectIncident={handleSelectIncident}
                  filterStatus={filterStatus}
                  filterType={filterType}
                  showHospitals={showHospitals}
                  showPolice={showPolice}
                  showFireStations={showFireStations}
                />
              </div>
            </div>
          )}
        </main>
      </div>

      {/* MODALS */}
      
      {/* 1. Quick Incident Report Modal */}
      <ReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        onSubmit={handleCreateIncident}
        existingIncidents={incidents}
        onStartMapPick={() => {
          setIsPickingLocation(true);
          setActiveTab('map');
          showToast('Click anywhere on the map to place your incident pin');
        }}
        pickedCoords={pickedCoords}
      />

      {/* 2. Responder Console Modal */}
      <ResponderConsoleModal
        isOpen={isResponderModalOpen}
        onClose={() => setIsResponderModalOpen(false)}
        incident={responderTargetIncident}
        onUpdateStatus={handleUpdateStatus}
        onVerify={handleVerify}
        currentResponder={currentResponder}
        onLoginResponder={(resp) => {
          setCurrentResponder(resp);
          showToast(`Welcome, ${resp.role} ${resp.name} (${resp.badgeNumber})`);
        }}
        onLogoutResponder={() => {
          setCurrentResponder(null);
          showToast('Signed out of responder console');
        }}
      />

      {/* 3. Incident Details Modal */}
      <IncidentDetailsModal
        incident={selectedIncident}
        onClose={() => setIsDetailsModalOpen(false)}
        onOpenResponderCommand={handleOpenResponderForIncident}
        onFindNearbyServices={handleFindNearbyServices}
      />

      {/* 4. Beginner Laptop Instructions Guide Modal */}
      <BeginnerGuideModal
        isOpen={isGuideModalOpen}
        onClose={() => setIsGuideModalOpen(false)}
        onResetDemoData={() => {
          incidentService.resetToDemo();
          showToast('Demo incidents restored successfully');
        }}
      />
    </div>
  );
}
