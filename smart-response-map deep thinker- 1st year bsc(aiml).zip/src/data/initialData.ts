import { EmergencyFacility, Incident } from '../types';

// Centered around a vibrant metro coordinate (e.g. San Francisco / Oakland / Metro Bay area)
export const MAP_CENTER: [number, number] = [37.7749, -122.4194];

export const INITIAL_INCIDENTS: Incident[] = [
  {
    id: 'inc-demo-1',
    reportCode: 'SRM-8101',
    type: 'fire',
    title: 'Commercial Restaurant 2-Alarm Kitchen Fire',
    description: 'Heavy black smoke and visible flames emanating from the ventilation duct of a commercial kitchen. Restaurant patrons evacuated, but adjacent bakery staff may still be inside.',
    location: {
      lat: 37.7795,
      lng: -122.4182,
      address: '742 Market St, Civic Center'
    },
    priority: 'critical',
    priorityReasons: [
      'Rapid fire hazard in dense commercial structure',
      'Flames spreading through ventilation duct'
    ],
    status: 'ongoing',
    verificationStatus: 'verified',
    reportedAt: Date.now() - 1000 * 60 * 25, // 25 mins ago
    updatedAt: Date.now() - 1000 * 60 * 10,
    reporterName: 'Carlos M. (Store Manager)',
    reporterContact: '+1 555-019-4421',
    imageUrl: 'https://images.unsplash.com/photo-1542385151-efd9000785a0?w=800&auto=format&fit=crop&q=80',
    assignedUnit: 'Engine 4 & Ladder 2 (Dispatched)',
    isDemo: true,
    responderNotes: [
      {
        id: 'log-1',
        timestamp: Date.now() - 1000 * 60 * 20,
        responderName: 'Sarah Lin (Battalion Chief)',
        badgeNumber: 'FD-8902',
        action: 'Verified & Upgraded Priority',
        note: 'Confirmed structural fire on second floor roof exhaust. Evacuation perimeter established.'
      },
      {
        id: 'log-2',
        timestamp: Date.now() - 1000 * 60 * 10,
        responderName: 'Alex Vance (Chief Dispatcher)',
        badgeNumber: 'DISP-4421',
        action: 'Unit Assigned',
        note: 'Engine 4 on scene connecting hydrants. Ladder 2 checking roof ventilation.'
      }
    ]
  },
  {
    id: 'inc-demo-2',
    reportCode: 'SRM-8102',
    type: 'accident',
    title: '3-Car Collision with Entrapment at Highway Ramp',
    description: 'Multi-vehicle collision at the freeway on-ramp. One sedan flipped on its side. Driver is conscious but trapped by deformed driver side door. Traffic completely halted.',
    location: {
      lat: 37.7698,
      lng: -122.4089,
      address: 'I-80 Westbound On-ramp at 8th St'
    },
    priority: 'critical',
    priorityReasons: [
      'Trapped victim in rolled vehicle',
      'High-speed multi-car highway accident',
      'Arterial transit route obstruction'
    ],
    status: 'ongoing',
    verificationStatus: 'verified',
    reportedAt: Date.now() - 1000 * 60 * 42,
    updatedAt: Date.now() - 1000 * 60 * 15,
    reporterName: 'David K. (Commuter)',
    reporterContact: '+1 555-019-3388',
    assignedUnit: 'Rescue Medic 9 & Highway Patrol Unit 12',
    isDemo: true,
    duplicateCount: 2,
    responderNotes: [
      {
        id: 'log-3',
        timestamp: Date.now() - 1000 * 60 * 35,
        responderName: 'Jordan Roy (EMS Lead)',
        badgeNumber: 'EMS-1105',
        action: 'Dispatched Heavy Extrication',
        note: 'Hydraulic jaws of life unit arriving. Jaws deployed to free driver.'
      }
    ]
  },
  {
    id: 'inc-demo-3',
    reportCode: 'SRM-8103',
    type: 'flood',
    title: 'Underpass Flash Flood - Stalled Passenger Van',
    description: 'Storm drain blowout has caused 3.5 feet of standing water in the underpass. Passenger minivan stalled in middle of deep water. 4 occupants safely on vehicle roof.',
    location: {
      lat: 37.7654,
      lng: -122.4285,
      address: '14th St Railroad Underpass & Harrison'
    },
    priority: 'high',
    priorityReasons: [
      'Rapid water accumulation blocking road',
      'Stranded vehicle occupants in rising runoff'
    ],
    status: 'pending',
    verificationStatus: 'unverified',
    reportedAt: Date.now() - 1000 * 60 * 14,
    updatedAt: Date.now() - 1000 * 60 * 14,
    reporterName: 'Anonymous Citizen',
    isDemo: true,
    responderNotes: []
  },
  {
    id: 'inc-demo-4',
    reportCode: 'SRM-8104',
    type: 'medical',
    title: 'Sudden Cardiac Collapse on Metro Transit Platform',
    description: 'Elderly male collapsed near ticket turnstiles. Bystanders initiating CPR with automated external defibrillator (AED) retrieved by station agent.',
    location: {
      lat: 37.7831,
      lng: -122.4077,
      address: 'Powell St Transit Station B2 Level'
    },
    priority: 'critical',
    priorityReasons: [
      'Life-threatening cardiac arrest indicated',
      'Active bystander CPR & AED deployment'
    ],
    status: 'ongoing',
    verificationStatus: 'verified',
    reportedAt: Date.now() - 1000 * 60 * 8,
    updatedAt: Date.now() - 1000 * 60 * 5,
    reporterName: 'Station Agent Marcus L.',
    reporterContact: '+1 555-019-7102',
    assignedUnit: 'Rapid Medic Ambulance 3',
    isDemo: true,
    responderNotes: [
      {
        id: 'log-4',
        timestamp: Date.now() - 1000 * 60 * 6,
        responderName: 'Jordan Roy (EMS Lead)',
        badgeNumber: 'EMS-1105',
        action: 'En Route',
        note: 'Medic 3 ETA 2 minutes. Pulse reported regained post-shock.'
      }
    ]
  },
  {
    id: 'inc-demo-5',
    reportCode: 'SRM-8105',
    type: 'hazard',
    title: 'Fallen High-Voltage Power Line with Sparking Cable',
    description: 'Large pine branch snapped and downed main power lines across residential sidewalk. Cable is arcing on wet asphalt. Perimeter needs securing before pedestrian rush hour.',
    location: {
      lat: 37.7582,
      lng: -122.4144,
      address: '22nd St & Mission Residential Corridor'
    },
    priority: 'high',
    priorityReasons: [
      'Live sparking power lines on wet surface',
      'Pedestrian electrocution hazard'
    ],
    status: 'pending',
    verificationStatus: 'unverified',
    reportedAt: Date.now() - 1000 * 60 * 30,
    updatedAt: Date.now() - 1000 * 60 * 30,
    reporterName: 'Elena Rostova',
    isDemo: true,
    responderNotes: []
  },
  {
    id: 'inc-demo-6',
    reportCode: 'SRM-8106',
    type: 'accident',
    title: 'Minor Intersection Fender Bender - Cleared to Shoulder',
    description: 'Two cars grazed bumpers while turning. No injuries reported, vehicles moved to parking shoulder. Traffic moving smoothly.',
    location: {
      lat: 37.7885,
      lng: -122.4321,
      address: 'Pine St & Fillmore Intersection'
    },
    priority: 'low',
    priorityReasons: [
      'No injuries, vehicles mobile and cleared'
    ],
    status: 'resolved',
    verificationStatus: 'verified',
    reportedAt: Date.now() - 1000 * 60 * 120,
    updatedAt: Date.now() - 1000 * 60 * 45,
    reporterName: 'Patrol Officer Chang',
    assignedUnit: 'Patrol Car 104',
    isDemo: true,
    responderNotes: [
      {
        id: 'log-5',
        timestamp: Date.now() - 1000 * 60 * 50,
        responderName: 'Patrol Officer Chang',
        badgeNumber: 'MPD-602',
        action: 'Incident Resolved',
        note: 'Information exchanged, non-injury report filed. Road completely open.'
      }
    ]
  },
  {
    id: 'inc-demo-7',
    reportCode: 'SRM-8107',
    type: 'fire',
    title: 'Trash Bin Smoldering - Extinguished',
    description: 'Metal public disposal bin smoking from discarded barbecue briquette. Local shopkeeper extinguished with dry chemical canister.',
    location: {
      lat: 37.7635,
      lng: -122.4412,
      address: 'Castro St & 18th Plaza'
    },
    priority: 'low',
    priorityReasons: [
      'Contained small smoldering container extinguished'
    ],
    status: 'resolved',
    verificationStatus: 'verified',
    reportedAt: Date.now() - 1000 * 60 * 180,
    updatedAt: Date.now() - 1000 * 60 * 150,
    reporterName: 'Community Watch Lead',
    isDemo: true,
    responderNotes: [
      {
        id: 'log-6',
        timestamp: Date.now() - 1000 * 60 * 160,
        responderName: 'Sarah Lin (Battalion Chief)',
        badgeNumber: 'FD-8902',
        action: 'Inspected & Cleared',
        note: 'Thermal imaging confirms no residual heat signatures.'
      }
    ]
  }
];

export const EMERGENCY_FACILITIES: EmergencyFacility[] = [
  {
    id: 'fac-1',
    name: 'San Francisco General Trauma Hospital',
    type: 'hospital',
    location: {
      lat: 37.7558,
      lng: -122.4048,
      address: '1001 Potrero Ave, San Francisco'
    },
    phone: '+1 628-206-8000',
    availableUnits: 14,
    status: 'available'
  },
  {
    id: 'fac-2',
    name: 'UCSF Medical Center at Mission Bay',
    type: 'hospital',
    location: {
      lat: 37.7678,
      lng: -122.3921,
      address: '1825 4th St, San Francisco'
    },
    phone: '+1 415-353-1000',
    availableUnits: 9,
    status: 'available'
  },
  {
    id: 'fac-3',
    name: 'Metropolitan Fire Station 4 (Engine & Rescue)',
    type: 'fire_station',
    location: {
      lat: 37.7812,
      lng: -122.4012,
      address: '449 Howard St, SoMa'
    },
    phone: '+1 415-558-3200',
    availableUnits: 4,
    status: 'available'
  },
  {
    id: 'fac-4',
    name: 'Mission District Fire Station 7',
    type: 'fire_station',
    location: {
      lat: 37.7601,
      lng: -122.4215,
      address: '2300 Folsom St, Mission District'
    },
    phone: '+1 415-558-3207',
    availableUnits: 3,
    status: 'available'
  },
  {
    id: 'fac-5',
    name: 'Central Police Station Precinct 1',
    type: 'police',
    location: {
      lat: 37.7992,
      lng: -122.4095,
      address: '766 Vallejo St, North Beach'
    },
    phone: '+1 415-315-2400',
    availableUnits: 8,
    status: 'available'
  },
  {
    id: 'fac-6',
    name: 'Southern Police Station & Marine Unit',
    type: 'police',
    location: {
      lat: 37.7725,
      lng: -122.3892,
      address: '1251 3rd St, Mission Bay'
    },
    phone: '+1 415-399-9301',
    availableUnits: 6,
    status: 'available'
  }
];

export const DEMO_RESPONDERS = [
  {
    id: 'resp-1',
    name: 'Alex Vance',
    badgeNumber: 'DISP-4421',
    role: 'Chief Dispatcher',
    agency: 'City Emergency Operations',
    passcode: '1234',
    accessLevel: 'admin'
  },
  {
    id: 'resp-2',
    name: 'Sarah Lin',
    badgeNumber: 'FD-8902',
    role: 'Fire Battalion Chief',
    agency: 'Metropolitan Fire Dept',
    passcode: '1234',
    accessLevel: 'admin'
  },
  {
    id: 'resp-3',
    name: 'Jordan Roy',
    badgeNumber: 'EMS-1105',
    role: 'Lead Paramedic',
    agency: 'Emergency Medical Services',
    passcode: '1234',
    accessLevel: 'field'
  },
  {
    id: 'resp-4',
    name: 'Marcus Chen',
    badgeNumber: 'MPD-9011',
    role: 'Police Commander',
    agency: 'Metro Police',
    passcode: '1234',
    accessLevel: 'admin'
  }
];
