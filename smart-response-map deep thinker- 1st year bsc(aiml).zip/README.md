# SMART RESPONSE MAP 🚨
**Open Innovation Hackathon Edition**

A modern, responsive emergency incident coordination web application built with **React**, **TypeScript**, **Leaflet.js**, **OpenStreetMap**, and **Firebase / Local Real-Time Synchronization**.

---

## 🌟 Key Features

1. **Dashboard KPI Overview**: Real-time counters showing Total, Pending Review, Ongoing / Dispatched, and Resolved emergency incidents with tabular figures and instant status filtering.
2. **Interactive Live Incident Map (Leaflet.js & OpenStreetMap)**:
   - Dynamic colored markers:
     - 🔴 **Red**: Critical (Priority 1) emergencies with pulsating radar animation
     - 🟠 **Orange**: High Priority / Ongoing emergencies
     - 🟡 **Amber**: Pending civilian reports
     - 🟢 **Green**: Resolved & cleared incidents
   - Category-specific SVG icons for **Accidents**, **Fire & Smoke**, **Floods**, **Medical Emergencies**, and **Infrastructure Hazards**.
   - Interactive popups with 1-click incident details and command links.
   - Click-on-map to drop pins directly when reporting.
3. **Quick Incident Reporting**:
   - Incident category picker with visual icons.
   - Instant GPS location detection via device geolocation + Map click picker + street address search.
   - Optional photo upload with instant image preview & quick sample selector for hackathon testing.
   - Unique reference code generation (e.g. `#SRM-8102`).
4. **Smart Priority Engine (AI / Rule-based)**:
   - Analyzes civilian descriptions in real-time as you type for high-urgency keywords (*"trapped"*, *"cardiac"*, *"unconscious"*, *"flames spreading"*, *"flash flood"*, *"gas leak"*).
   - Generates an explainable severity score (1–100) and priority recommendation (*Critical P1*, *High P2*, *Medium P3*, *Low P4*) with transparent reasoning tags.
5. **Spatial Duplicate Detection**:
   - Haversine trigonometric calculation flags potential duplicate reports within 600m and 3 hours.
   - Calculates match confidence percentage and allows responders to consolidate duplicate civilian calls.
6. **Authorized Responder Command & Security**:
   - Role-based security for Fire Chiefs, EMS Leads, Police Commanders, and Chief Dispatchers.
   - Passcode verification (**Default demo passcode: `1234`**).
   - Verify civilian reports, mark false alarms, assign vehicle units (e.g., *Engine 4*, *Medic 9*), update statuses, and log tactical timestamps.
7. **Nearby Emergency Services**:
   - Displays real-time standby data for nearby **Hospitals & Trauma Centers**, **Police Stations**, and **Fire Stations**.
   - Calculates distance (in km) from selected incident or current user location.
   - Standby vehicle unit counters and quick-dial emergency telephone hotlines.
8. **Interactive Demo Mode & Real-Time Sync**:
   - Works immediately out-of-the-box without requiring Firebase configuration.
   - Multi-tab synchronization using browser BroadcastChannel (open 2 tabs to watch updates sync live!).
   - Easily connect your custom Firebase Firestore project via the built-in Settings modal if desired.

---

## 🚀 How to Run on Your Laptop (Beginner Guide)

### Prerequisites:
Make sure you have **Node.js** (version 18 or newer) installed on your laptop. If you don't have it, download it free from [https://nodejs.org](https://nodejs.org).

### 3 Simple Steps:

#### 1. Open Terminal or Command Prompt
Open your terminal (Terminal on Mac/Linux, Command Prompt / PowerShell on Windows, or the built-in terminal in VS Code) and navigate to the project folder:
```bash
cd smart-response-map
```

#### 2. Install Project Dependencies
Run this command once to install React, Leaflet, and Tailwind:
```bash
npm install
```

#### 3. Start the Development Server
Run the local dev command:
```bash
npm run dev
```

#### 4. Open in Your Browser
Open your browser and visit:
```
http://localhost:3000
```

---

## 🔑 Demo Responder Passcodes

To access the Authorized Responder Console:
- **Default PIN / Passcode**: `1234`
- Available profiles:
  - **Alex Vance** — Chief Dispatcher (City Emergency Operations)
  - **Sarah Lin** — Fire Battalion Chief (Metropolitan Fire Dept)
  - **Jordan Roy** — Lead Paramedic (Emergency Medical Services)
  - **Marcus Chen** — Police Commander (Metro Police)

---

## 📂 Project Architecture

```
├── index.html                   # HTML entry point with Leaflet stylesheets
├── package.json                 # Dependencies (React 19, Leaflet, Tailwind CSS)
├── src/
│   ├── App.tsx                  # Main application orchestrator
│   ├── types/
│   │   └── index.ts             # TypeScript definitions for Incidents & Facilities
│   ├── services/
│   │   ├── smartPriority.ts     # Natural language severity & priority scoring
│   │   ├── duplicateDetector.ts # Haversine spatial duplicate detection
│   │   └── incidentStorage.ts   # Real-time multi-tab storage & Firebase adapter
│   ├── data/
│   │   └── initialData.ts       # Hackathon demo incidents & emergency facilities
│   └── components/
│       ├── Sidebar.tsx          # Navy navigation sidebar
│       ├── Map/
│       │   └── IncidentMap.tsx  # Leaflet & OpenStreetMap interactive map
│       ├── Dashboard/
│       │   └── OverviewStats.tsx# Total, pending, ongoing, resolved KPI cards
│       ├── IncidentForm/
│       │   └── ReportModal.tsx  # Civilian incident reporting form with GPS
│       ├── Responder/
│       │   └── ResponderConsoleModal.tsx # Responder auth & verification panel
│       ├── Facilities/
│       │   └── NearbyServicesList.tsx    # Hospitals, police & fire stations
│       ├── Instructions/
│       │   └── BeginnerGuideModal.tsx    # In-app laptop run guide & Firebase settings
│       ├── IncidentsFeedView.tsx         # Incident queue & dispatch stream table
│       └── IncidentDetailsModal.tsx      # Incident details & tactical timeline
```
